<div class="form-user message js-message">
    <div class="logo" style="padding: 10px;">
        <img src="{{ config('site.url_static') . '/vendor/' . $group_name . '/' . $skin . '/images/logo_bak.png' }}" alt="">
    </div>
    <div class="inner-message" style="padding: 20px;text-transform: uppercase;">
        
    </div>
</div>
