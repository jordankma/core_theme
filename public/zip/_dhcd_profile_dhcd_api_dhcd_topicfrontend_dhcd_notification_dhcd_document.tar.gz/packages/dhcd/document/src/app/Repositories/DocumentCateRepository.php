<?php

namespace Dhcd\Document\App\Repositories;

use Adtech\Application\Cms\Repositories\Eloquent\Repository;
use Illuminate\Support\Facades\DB;
use Dhcd\Document\App\Models\DocumentCate;
use Cache;
/**
 * Class DemoRepository
 * @package Dhcd\Document\Repositories
 */
class DocumentCateRepository extends Repository
{

    /**
     * @return string
     */
    public function model()
    {
        return 'Dhcd\Document\App\Models\DocumentCate';
    }

    public function findAll() {

        $result = $this->model::query();
        return $result;
    }
    
    public function getCates(){
        
        if(Cache::has('list_cate')){            
            $cates = Cache::get('list_cate');            
            return $cates;            
        } else {
            $cates = DocumentCate::get()->toArray();
            $data = [];
            if($cates){
                Cache::forever('list_cate',$cates);
                $data = $cates;                
            }
            return $data;
        }        
    }
    
}
