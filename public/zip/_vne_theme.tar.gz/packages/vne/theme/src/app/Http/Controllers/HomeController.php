<?php

namespace Vne\Theme\App\Http\Controllers;

use Illuminate\Http\Request;
use Adtech\Application\Cms\Controllers\MController as Controller;


use Spatie\Activitylog\Models\Activity;
use Yajra\Datatables\Datatables;
use Validator,Datetime,Session,URL;

use Vne\Banner\App\Models\Banner;
use Vne\Contact\App\Models\Contact;
use Vne\News\App\Models\News;

use Vne\News\App\Repositories\NewsRepository;
use GuzzleHttp\Client;

class HomeController extends Controller
{
    private $messages = array(
        'name.regex' => "Sai định dạng",
        'required' => "Bắt buộc",
        'numeric'  => "Phải là số"
    );
    private $register_form = '{
        "data": {
          "load_default": [
            {
                "id" : 1,
                "title": "Tên đăng nhập",
                "hint_text": "Tên đăng nhập",
                "type": "text",
                "params": "user_name",
                "type_view": 0,
                "is_require": true,
                "is_search": true
            },
            {
                "id": 2,
                "title": "Đề tài",
                "params": "gioitinh",
                "hint_text": "Chọn giới tính",
                "type_view": 2,
                "is_require": true,
                "is_search": true,
                "data_view": [
                  {
                    "id": 1,
                    "title": "Nam"
                  },
                  {
                    "id": 2,
                    "title": "Nữ"
                  }
                ]
              },
              {
                "id": 3,
                "title": "Tỉnh/Thành phố",
                "params": "city",
                "hint_text": "Chọn tỉnh/thành",
                "type_view": 1,
                "type": "data",
                "is_require": true,
                "is_search": true,
                "data_view": [
                  {
                    "id": 1,
                    "title": "Hà Nội"
                  },
                  {
                    "id": 2,
                    "title": "Hưng Yên"
                  },
                  {
                    "id": 3,
                    "title": "Hải Phòng"
                  }
                ]
              },
              {
                "id": 4,
                "title": "Chọn công việc bạn yêu thich",
                "params": "chonABC",
                "hint_text": "Chọn giới tính",
                "type_view": 3,
                "is_require": true,
                "is_search": true,
                "data_view": [
                  {
                    "id": 1,
                    "title": "Thích đi học"
                  },
                  {
                    "id": 2,
                    "title": "Thích nghe nhạc"
                  },
                  {
                    "id": 2,
                    "title": "Thích ăn kem"
                  },
                  {
                    "id": 2,
                    "title": "Thích đá bóng"
                  },
                  {
                    "id": 2,
                    "title": "Thích ngủ"
                  }
                ]
              }
            ]
          ,
            "target": [
              {
            "id": 1,
            "title": "Hoc sinh",
          
            "form_data": [
              {
                "id": 1,
                "title": "Tên đăng nhập",
                "hint_text": "Tên đăng nhập",
                "type": "text",
                "params": "user_name",
                "type_view": 0,
                "is_require": true,
                "is_search": true
              },
              {
                "id": 2,
                "title": "Họ và tên",
                "params": "name",
                "type": "text",
                "hint_text": "Họ tên",
                "type_view": 0,
                "is_require": true,
                "is_search": true
              
              },
              {
                "id": 3,
                "title": "Tỉnh/Thành phố",
                "params": "city",
                "hint_text": "Chọn tỉnh/thành",
                "type_view": 1,
                "type": "data",
                "is_require": true,
                "is_search": true,
                "data_view": [
                  {
                    "id": 1,
                    "title": "Hà Nội"
                  },
                  {
                    "id": 2,
                    "title": "Hưng Yên"
                  },
                  {
                    "id": 3,
                    "title": "Hải Phòng"
                  }
                ]
              },
              {
                 "id": 4,
                "title": "Quận/ huyện",
                "params": "district",
                "hint_text": "Chọn Quận/huyện",
                "type_view": 1,
                "type": "api",
                "api": "",
                "is_require": true,
                "is_search": true,
                "data_view": [
                ]
              },
              {
                "id": 4,
                "title": "Tên bài viết",
                "params": "note",
                "hint_text": "Tên bài viết",
                "type" : "text",
                "type_view": 0,
                "is_require": true,
                "is_search": true
              },
              {
                "id": 3,
                "title": "Đề tài",
                "params": "topic",
                "hint_text": "Chọn đề tài",
                "type_view": 1,
                "is_require": true,
                "is_search": true,
                "data_view": [
                  {
                    "id": 1,
                    "title": "Đề tài 1"
                  },
                  {
                    "id": 2,
                    "title": "Đề tài 2"
                  },
                  {
                    "id": 3,
                    "title": "Đề tài 3"
                  }
                ]
              },
              {
                "id": 3,
                "title": "Đề tài",
                "params": "gioitinh",
                "hint_text": "Chọn giới tính",
                "type_view": 2,
                "is_require": true,
                "is_search": true,
                "data_view": [
                  {
                    "id": 1,
                    "title": "Nam"
                  },
                  {
                    "id": 2,
                    "title": "Nữ"
                  }
                ]
              },
              {
                "id": 3,
                "title": "Chọn công việc bạn yêu thich",
                "params": "chonABC",
                "hint_text": "Chọn giới tính",
                "type_view": 3,
                "is_require": true,
                "is_search": true,
                "data_view": [
                  {
                    "id": 1,
                    "title": "Thích đi học"
                  },
                  {
                    "id": 2,
                    "title": "Thích nghe nhạc"
                  },
                  {
                    "id": 2,
                    "title": "Thích ăn kem"
                  },
                  {
                    "id": 2,
                    "title": "Thích đá bóng"
                  },
                  {
                    "id": 2,
                    "title": "Thích ngủ"
                  }
                ]
              }
            ]
          },
              {
            "id": 2,
            "title": "Sinh vien di lam",
            "form_data": [
              {
                "id": 1,
                "title": "Tên đăng nhập",
                "hint_text": "Tên đăng nhập",
                "params": "user_name",
                "type" : "text",
                "type_view": 0,
                "is_require": true
              },
              {
                "id": 2,
                "title": "Họ và tên",
                "params": "name",
                "hint_text": "Họ tên",
                "type" : "text",
                "type_view": 0,
                "is_require": true
              },
              {
                "id": 3,
                "title": "Tỉnh/Thành phố",
                "params": "city",
                "hint_text": "Chọn tỉnh/thành",
                "type_view": 1,
                "is_require": true,
                "data_view": [
                  {
                    "id": 1,
                    "title": "Hà Nội"
                  },
                  {
                    "id": 2,
                    "title": "Hưng Yên"
                  },
                  {
                    "id": 3,
                    "title": "Hải Phòng"
                  }
                ]
              },
              {
                "id": 4,
                "title": "Tên bài viết",
                "params": "note",
                "hint_text": "Tên bài viết",
                "type" : "text",
                "type_view": 0,
                "is_require": true
              },
              {
                "id": 3,
                "title": "Đề tài",
                "params": "topic",
                "hint_text": "Chọn đề tài",
                "type_view": 1,
                "is_require": true,
                "data_view": [
                  {
                    "id": 1,
                    "title": "Đề tài 1"
                  },
                  {
                    "id": 2,
                    "title": "Đề tài 2"
                  },
                  {
                    "id": 3,
                    "title": "Đề tài 3"
                  }
                ]
              },
              {
                "id": 3,
                "title": "Đề tài",
                "params": "gioitinh",
                "hint_text": "Chọn giới tính",
                "type_view": 2,
                "is_require": true,
                "data_view": [
                  {
                    "id": 1,
                    "title": "Nam"
                  },
                  {
                    "id": 2,
                    "title": "Nữ"
                  }
                ]
              }
            ]
          }
              ]
         
        },
        "config": {
          "0": "input",
          "1": "selectbox",
          "2": "radio",
          "3": "checkbox"
        },
        "success": true,
        "message": "ok!"
      }';
    public function __construct( NewsRepository $newsRepository)
    {
        parent::__construct();
        $this->news = $newsRepository;
        Session::put('url.intended', URL::full());
    }

    public function index(){
        $theme = config('site.theme');
        if($theme == 'theme1'){
            $id_position_banner_trangchu = config('site.banner_trang_chu_id');
            $list_banner = Banner::where('position',$id_position_banner_trangchu)->get();

            $thongbaobtc = config('site.news_box.thongbaobtc');
            $list_thong_bao_btc = $this->news->getNewsByBox($thongbaobtc,null,5);

            $tinnong = config('site.news_box.tinnong');
            $list_news_hot = $this->news->getNewsByBox($tinnong,null,5);
            
            $sukien = config('site.news_box.sukien');
            $list_news_event = $this->news->getNewsByBox($sukien,null,4);

            $hanhtrinhgiaothonghocduong = config('site.news_box.hanhtrinhgiaothonghocduong');
            $list_news_hanh_trinh_truong = $this->news->getNewsByBox($hanhtrinhgiaothonghocduong,4,4);
            $list_news_hanh_trinh_tinh = $this->news->getNewsByBox($hanhtrinhgiaothonghocduong,5,4);
            $list_news_hanh_trinh_toanquoc = $this->news->getNewsByBox($hanhtrinhgiaothonghocduong,6,4);
            $list_news_hanh_trinh_khac = $this->news->getNewsByBox($hanhtrinhgiaothonghocduong,7,4);
            
            $hinhanhvideo = config('site.news_box.hinhanhvideo');

            $list_news_anh_video_1 = $this->news->getNewsByBox($hinhanhvideo,8,4);
            $list_news_anh_video_2 = $this->news->getNewsByBox($hinhanhvideo,9,4);

            $data = [
                'list_banner' => $list_banner,
                'list_thong_bao_btc' => $list_thong_bao_btc,
                'list_news_hot' => $list_news_hot,
                'list_news_event' => $list_news_event,
                'list_news_hanh_trinh_truong' => $list_news_hanh_trinh_truong,
                'list_news_hanh_trinh_tinh' => $list_news_hanh_trinh_tinh,
                'list_news_hanh_trinh_toanquoc' => $list_news_hanh_trinh_toanquoc,
                'list_news_hanh_trinh_khac' => $list_news_hanh_trinh_khac,
                'list_news_anh_video_1' => $list_news_anh_video_1,
                'list_news_anh_video_2' => $list_news_anh_video_2
                
            ];
            return view('VNE-THEME::modules.index.index',$data); 
        }
        elseif($theme == 'theme2'){
            $id_position_banner_trangchu = config('site.banner_trang_chu_id');
            $list_banner = Banner::where('position',$id_position_banner_trangchu)->get();

            $thongbaohoidongdoi = config('site.news_box.thongbaohoidongdoi');
            $list_news_thong_bao_hoi_dong_doi = $this->news->getNewsByBox($thongbaohoidongdoi,null,5);

            $renluyendoivien = config('site.news_box.renluyendoivien');
            $list_news_ren_luyen_doi_vien = $this->news->getNewsByBox($renluyendoivien,null,5);

            $sotayrenluyen = config('site.news_box.sotayrenluyen');
            $list_news_so_tay_ren_luyen = $this->news->getNewsByBox($sotayrenluyen,null,5);
            $hinhanhvideo = config('site.news_box.hinhanhvideo');
            $list_news_hinh_anh_video = $this->news->getNewsByBox($hinhanhvideo,null,5);


            $data = [
                'list_banner' => $list_banner,    
                'list_news_thong_bao_hoi_dong_doi' => $list_news_thong_bao_hoi_dong_doi,    
                'list_news_ren_luyen_doi_vien' => $list_news_ren_luyen_doi_vien,    
                'list_news_so_tay_ren_luyen' => $list_news_so_tay_ren_luyen,    
                'list_news_hinh_anh_video' => $list_news_hinh_anh_video, 
            ];
            return view('VNE-THEME::modules.index.index',$data);    
        }
    }

    public function listMember(){
      return view('VNE-THEME::modules.search.search_member');
    }

    public function listResult(){
      return view('VNE-THEME::modules.search.search_result');
    }

    public function showContact(){
      return view('VNE-THEME::modules.contact.contact');
    }

    public function saveContact(Request $request){
        $contact = new Contact();
        $contact->name = $request->input('name');
        $contact->email = $request->input('email_contact');
        $contact->content = $request->input('content');
        $contact->created_at = new Datetime();
        if($contact->save()) {
            return view('VNE-THEME::modules.contact.contact')->with('thongbao','Gửi liên hệ thành công');
        }

    }

    public function getTryExam(){
       return view('VNE-THEME::modules.contest.index'); 
    }

    public function listNews(Request $request, $alias = null){
        if($alias==null){
            $list_news = News::orderBy('news_id', 'desc')->paginate(10);  
        } else {
            $list_news = $this->news->getNewsByCate($alias,10);    
        }
        $data = [
            'list_news' => $list_news     
        ];
        return view('VNE-THEME::modules.news.list',$data);
    }

    public function listNewsByBox(Request $request, $alias = null){
        $list_news = $this->news->getNewsByBox($alias,null,10); 
        $data = [
            'list_news' => $list_news     
        ];
        return view('VNE-THEME::modules.news.list',$data);
    }


    public function detailNews($alias){
        $news = News::where('title_alias',$alias)->first();  
        $data = [
            'news' => $news     
        ];
        return view('VNE-THEME::modules.news.details',$data);
    }

    public function listExam(){
        $list_banner = array();
        $data = [
            'list_banner' => $list_banner,
            
        ];
        return view('VNE-THEME::modules.index.index');
    }

    public function detailExam(){
        $list_banner = array();
        $data = [
            'list_banner' => $list_banner,
            
        ];
        return view('VNE-THEME::modules.index.index');
    }

    public function scheduleExam(){
        return view('VNE-THEME::modules.exam.schedule');
    }

    public function showRegisterMember(Request $request){
        $register_form = $this->register_form;
        $register_form_array = json_decode($register_form,true);
        $data = [
          'list_object' => $register_form_array['data']['target'],
          'config' => $register_form_array['config'],
          'form_data_default' => $register_form_array['data']['load_default']
        ];
        return view('VNE-THEME::modules.member.register',$data);
    }

    public function getFormRegister(Request $request){
      $validator = Validator::make($request->all(), [
            'object_id' => 'required|numeric',
        ], $this->messages);
        if (!$validator->fails()) {
          $object_id = $request->input('object_id');
          $register_form = $this->register_form;
          $register_form_array = json_decode($register_form,true);
          foreach ($register_form_array['data']['target'] as $key => $value ) {
            if($value['id'] == $object_id){
              $form_data = $value['form_data'];
              break; 
            }      
          }
          $str = '';
          if(count($form_data) > 0){
            foreach ($form_data as $element){
              $require = $element['is_require'] == true ? 'required=""' : ''; 
              $text_muted = $element['is_require'] == true ? '<small class="text-muted">*</small>' : '';          
              if($element['type_view'] == 0){  
                $str .= 
                '<div class="form-group">'
                    .'<label>' . $element['title'] . '</label>'
                    .'<div class="input">'
                    .    '<input type="' . $element['type'] . '" name="' . $element['params'] . '" class="form-control" placeholder="' . $element['hint_text'] . '"'
                    . $require .'>'
                    . $text_muted
                    .'</div>'
                .'</div>';
              } 
              elseif($element['type_view'] == 1) { 
                $str .=
                '<div class="form-group">'
                    .'<label>' . $element['title'] . '</label>'
                    .'<div class="input">'
                        .'<select class="form-control" name="' . $element['params'] . '"' . $require . '>'
                        .    '<option>' . $element['title'] .'</option>'; 
                            if(count($element['data_view'])>0){
                              foreach ($element['data_view'] as $element2){
                                  $str .= '<option value="' . $element2['id'] . '">' . $element2['title'] . '</option>';
                              }
                            }
                        $str .= '</select>';
                        $str .= $text_muted;
                    $str .= '</div>'
                .'</div>';
              }
              elseif($element['type_view'] == 2){
                $str .=
                '<div class="form-group">'
                    .'<label>' . $element['title'] . '</label>'
                    .'<div class="input">';
                        if(count($element['data_view'])>0){
                          foreach ($element['data_view'] as $element3){
                              $str .= '<label><input type="radio" name="' . $element['params'] . '" value="' . $element3['id'] . '">' . $element3['title'] .'</label>';
                          }
                        }
                        $str .= $text_muted;
                    $str .= '</div>'
                .'</div>';
              }
              elseif($element['type_view'] == 3){
                $str .=  
                '<div class="form-group">'
                    .'<label>' . $element['title'] . '</label>'
                    .'<div class="input">';
                        if(count($element['data_view'])>0){
                          foreach ($element['data_view'] as $element4){
                              $str .= '<label><input type="checkbox" name="' . $element['params'] . '" value="' . $element4['id'] .'">' . $element4['title'] .'</label>';
                          }
                        }
                        $str .= $text_muted;
                    $str .= '</div>'
                .'</div>';
              }
            }
          }
          return response()->json(['str'=>$str]);
        } else {
          return $validator->messages();
        }        
    }

    public function updateRegisterMember(){
    	$list_banner = array();

    	$data = [
    		'list_banner' => $list_banner,
    		
    	];
        return view('VNE-THEME::modules.index.index');
    }

    public function getDistrict(Request $request){
        $list_district = array();
        $list_district_json = array();
        if(!empty($list_district)){
            foreach ($list_district as $key => $district) {
                $list_district_json[] = [
                    'district_id' => $district->district_id,
                    'name' => $district->name
                ];
            }
        }
        return json_encode($list_district_json);      
    }

    public function getSchool(Request $request){
        $list_school = array();
        $list_school_json = array();
        if(!empty($list_school)){
            foreach ($list_school as $key => $school) {
                $list_school_json[] = [
                    'school_id' => $school->school_id,
                    'name' => $school->name
                ];
            }
        }
        return json_encode($list_school_json);      
    }

    public function getClass(Request $request){
        $list_class = array();
        $list_class_json = array();
        if(!empty($list_class)){
            foreach ($list_class as $key => $class) {
                $list_class_json[] = [
                    'class_id' => $class->class_id,
                    'name' => $class->name
                ];
            }
        }
        return json_encode($list_class_json);      
    }
}
