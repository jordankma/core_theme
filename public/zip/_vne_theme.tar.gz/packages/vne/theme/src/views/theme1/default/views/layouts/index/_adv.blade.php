<div class="col-12">
	<!-- adv -->
	<div class="section adv">
		<a href="" target="_blank">
			<img src="{{ config('site.url_static') .'/vendor/' . $group_name . '/' . $skin . '/images/banner_donvitaitro.jpg' }}">
		</a>
	</div>
	<!-- adv end -->
</div>