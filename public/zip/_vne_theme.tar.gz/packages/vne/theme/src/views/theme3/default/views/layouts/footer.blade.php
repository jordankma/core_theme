<footer class="footer">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 branb">
				<img src="images/logo.png" alt="">
				<p>CUỘC THI TUỔI TRẺ HỌC VÀ LÀM THEO TƯ TƯỞNG ĐẠO ĐỨC, PHONG CÁCH HỒ CHÍ MINH NĂM 2018</p>
			</div>
			<div class="col-lg-9 info">
				<div class="headline">THƯỜNG TRỰC BAN TỔ CHỨC:</div>
				<div class="info-inner">
					<div class="block">
						<h2 class="name">BỘ GIÁO DỤC VÀ ĐÀO TẠO <br>VỤ GIÁO DỤC CHÍNH TRỊ <br> VÀ CÔNG TÁC HỌC SINH - SINH VIÊN</h2>
						<ul class="info-contact">
							<li><i class="fa fa-address"></i> 35 Đại Cồ Việt, Hà Nội.</li>
							<li><i class="fa fa-phone"></i> Hỗ trợ công tác tổ chức: 024.38694984</li>
						</ul>
					</div>
					<div class="block">
						<h2 class="name">TẬP ĐOÀN GIÁO DỤC EGROUP</h2>
						<ul class="info-contact">
							<li><i class="fa fa-address"></i> Tầng 3, Tòa Nhà 25T1, Hoàng Đạo Thúy, Trung Hòa, Cầu Giấy, Hà Nội</li>
							<li><i class="fa fa-phone"></i> Hỗ trợ kỹ thuật: 1900636444 (8h - 22h hàng ngày)</li>
							<li><i class="fa fa-email"></i> hocvalamtheobac@egroup.vn</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer>