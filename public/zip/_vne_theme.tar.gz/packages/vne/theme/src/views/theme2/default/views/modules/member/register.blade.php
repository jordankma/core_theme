@extends('VNE-THEME::layouts.master')
@section('content')

@stop