<footer class="footer">
	<div class="container">
		<div class="footer-info">
			<div class="footer-contact">
				<p><img src="images/logo.png" alt=""></p>
				<h4>HỖ TRỢ NỘI DUNG RÈN LUYỆN HỘI ĐỒNG ĐỘI TRUNG ƯƠNG</h4>
				<ul>
					<li><i class="fa fa-address"></i> Địa chỉ: 62 Bà Triệu, Quận Hoàn Kiếm, Thành phố Hà Nội</li>
					<li><i class="fa fa-email"></i>Email hỗ trợ: renluyendoivien@gmail.com</li>
					<li><i class="fa fa-phone"></i>Hotline: 1900.636.444 ( Trong giờ hành chính từ thứ 2 - thứ 6) <br>1900.636.228 (
						Ngoài giờ hành chính,T7 + CN và các ngày Lễ, Tết)</li>
				</ul>
			</div>
			<div class="footer-facebook">
				<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ffacebook&tabs=timeline&width=340&height=230&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId"
				 width="340" height="230" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"
				 allow="encrypted-media"></iframe>
			</div>
		</div>
		<div class="copyright">
			<a href="">Design by VNEDUTECH.VN</a>
		</div>
	</div>
</footer>