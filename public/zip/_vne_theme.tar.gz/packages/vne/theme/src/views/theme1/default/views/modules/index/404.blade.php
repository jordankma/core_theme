{{-- @extends('layouts.exception') --}}

{{-- Page content --}}
{{-- @section('content')
    <img src=""
    <div class="hgroup" style="text-align: center; margin-top: 10%; font-size: 30px;">
        <h1>THÔNG BÁO BẢO TRÌ</h1>
        <h2>HỆ THỐNG ĐANG CẬP NHẬT MỜI BẠN QUAY LẠI SAU 15h00 NGÀY 15/1/2019</h2>
        <p>Mọi thắc mắc xin liên hệ {{ isset($SETTING['hotline']) ? $SETTING['hotline'] : '' }} - {{ isset($SETTING['phone']) ? $SETTING['phone'] : '' }}</p>
    </div>
@stop --}}
<img src="http://static.giaothonghocduong.com.vn/files/photos/bao_tri.png"> 
