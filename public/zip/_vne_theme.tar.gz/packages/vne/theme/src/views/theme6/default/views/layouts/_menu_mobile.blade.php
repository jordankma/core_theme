<div class="nav-trigger js-trigger">
	<span class="bar"></span>
	<span class="bar"></span>
	<span class="bar"></span>
</div>
<div class="slideout js-slideout">
	<div class="inner">
		<ul class="nav">
			<li class="nav-item js-toggle-login"><i class="fa fa-user"></i> Đăng nhập</li>
			<li class="nav-item js-toggle-registration"><i class="fa fa-user"></i> Đăng ký</li>
		</ul>
		<nav class="slideout-navbar">
			<ul class="nav">
				<li class="nav-item">
					<a href="" class="nav-link">Giới thiệu</a>
					<ul>
						<li class="nav-item">
							<a href="" class="nav-link">Demo</a>
						</li>
						<li class="nav-item">
							<a href="" class="nav-link">Demo</a>
							<ul>
								<li class="nav-item">
									<a href="" class="nav-link">Demo</a>
								</li>
								<li class="nav-item">
									<a href="" class="nav-link">Demo</a>
								</li>
							</ul>
						</li>
					</ul>
				</li>
				<li class="nav-item">
					<a href="" class="nav-link">Tự luận</a>
					<ul>
						<li class="nav-item">
							<a href="" class="nav-link">Demo</a>
						</li>
						<li class="nav-item">
							<a href="" class="nav-link">Demo</a>
							<ul>
								<li class="nav-item">
									<a href="" class="nav-link">Demo</a>
								</li>
								<li class="nav-item">
									<a href="" class="nav-link">Demo</a>
								</li>
							</ul>
						</li>
					</ul>
				</li>
				<li class="nav-item">
					<a href="" class="nav-link">Tra cứu</a>
					<ul>
						<li class="nav-item">
							<a href="" class="nav-link">Demo</a>
						</li>
						<li class="nav-item">
							<a href="" class="nav-link">Demo</a>
							<ul>
								<li class="nav-item">
									<a href="" class="nav-link">Demo</a>
								</li>
								<li class="nav-item">
									<a href="" class="nav-link">Demo</a>
								</li>
							</ul>
						</li>
					</ul>
				</li>
				<li class="nav-item">
					<a href="" class="nav-link">Văn bản</a>
					<ul>
						<li class="nav-item">
							<a href="" class="nav-link">Demo</a>
						</li>
						<li class="nav-item">
							<a href="" class="nav-link">Demo</a>
							<ul>
								<li class="nav-item">
									<a href="" class="nav-link">Demo</a>
								</li>
								<li class="nav-item">
									<a href="" class="nav-link">Demo</a>
								</li>
							</ul>
						</li>
					</ul>
				</li>
				<li class="nav-item">
					<a href="" class="nav-link">Tin tức</a>
				</li>
				<li class="nav-item">
					<a href="" class="nav-link">Liên hệ</a>
				</li>
			</ul>
		</nav>
		<div class="contact">
			<p class="phone">Hỗ trợ: 02613 545 662</p>
			<p class="email">Email: timhieubiendao@gmail.com</p>
		</div>

	</div>
</div>