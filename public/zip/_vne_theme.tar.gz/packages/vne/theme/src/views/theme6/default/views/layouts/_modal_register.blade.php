<div class="form-user from-registration js-registration">
	<div class="logo">
		<img src="src/images/egroup-logo.png" alt="">
	</div>
	<form action="" class="form">
		<p>Thành viên mới?</p>
		<div class="form-group">
			<input type="username" class="form-control" placeholder="Email/Username">
			<small>(Tên đăng nhập viết liền không dấu, không chứa kí tự đặc biệt)</small>
		</div>
		<div class="form-group">
			<input type="password" class="form-control" placeholder="Mật khẩu">
		</div>
		<div class="form-group">
			<input type="password" class="form-control" placeholder="Xác nhận mật khẩu">
		</div>
		<div class="form-group">
			<input type="phone" class="form-control" placeholder="Số điện thoại">
		</div>
		<button type="submit" class="btn btn-success">Đăng ký</button>
	</form>
</div>