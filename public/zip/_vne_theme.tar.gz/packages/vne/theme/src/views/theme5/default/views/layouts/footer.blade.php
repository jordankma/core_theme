<footer class="footer">
	<div class="container">
		<div class="row">
			<div class="col-md-8 info">
				<p>THƯỜNG TRỰC BAN TỔ CHỨC</p>
				<div class="row inner">
					<div class="col-md-6">
						<p class="title">BAN THANH NIÊN TRƯỜNG HỌC<br>TRUNG ƯƠNG ĐOÀN TNCS HỒ CHÍ MINH</p>
						<ul>
							<li>64 Bà Triệu, Quận Hoàn Kiếm, Thành Phố Hà Nội</li>
							<li>Đồng Chí: Nguyễn Bá Cát</li>
							<li>Cán bộ Ban Thanh Niên Trường học TW Đoàn</li>
							<li>Điện thoại: 0912.104.345</li>
						</ul>
					</div>
					<div class="col-md-6">
						<p class="title">CÔNG TY CỔ PHẦN TẬP ĐOÀN GIÁO DỤC EGROUP </p>
						<ul>
							<li>Tầng 3, Tòa Nhà 25T1, Hoàng Đạo Thúy, Trung Hòa, Cầu Giấy, Hà Nội</li>
							<li>Đồng Chí: Phạm Thu Huế</li>
							<li>Phòng Cộng Đồng, Công Ty Cổ Phần Tập Đoàn Giáo Dục Egroup</li>
							<li>ĐTDĐ: 0962 411 566</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-md-4 logo">
				<p>ĐƠN VỊ TRUYỀN THÔNG</p>
				<div class="inner">
					<a href="http://"><img src="{{ asset('/vendor/' . $group_name . '/' . $skin . '/images/mgc.png?t=' . time()) }}" alt=""></a>
				</div>
			</div>
		</div>
	</div>
</footer>