<footer class="footer">
	<div class="footer-logo-list">
		<div class="container">
			<div class="carousel js-carousel-03">
				<a class="carousel-item" href="">
					<div class="logo">
						<img src="images/vnedutech-logo.png" alt="">
					</div>
				</a>
				<a class="carousel-item" href="">
					<div class="logo">
						<img src="images/logo_bak.png" alt="">
					</div>
				</a>
				<a class="carousel-item" href="">
					<div class="logo">
						<img src="images/mgc.png" alt="">
					</div>
				</a>
				<a class="carousel-item" href="">
					<div class="logo">
						<img src="images/thieunien.png" alt="">
					</div>
				</a>
				<a class="carousel-item" href="">
					<div class="logo">
						<img src="images/hoahoctro.png" alt="">
					</div>
				</a>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<h4>TM THƯỜNG TRỰC BAN TỔ CHỨC</h4>
				<p><i class="fa fa-address"></i> Tầng 2, Tòa nhà 25T1, Hoàng Đạo Thúy, Trung Hòa , Cầu Giấy , Hà Nội</p>
				<p><i class="fa fa-phone"></i> Hotline: 1900 636 444 (8h - 22h hàng ngày)</p>
			</div>
			<div class="col-md-4">
				<h4>VỤ PHỔ BIẾN, PHÁP LUẬT GIÁO DỤC, BỘ TƯ PHÁP</h4>
				<p><i class="fa fa-address"></i> 58-60 Trần Phú, Ba Đình, Hà Nội</p>
			</div>
			<div class="col-md-4">
				<h4>CÔNG TY CP TẬP ĐOÀN GIÁO DỤC EGROUP</h4>
				<p><i class="fa fa-address"></i> Tầng 2, Tòa Nhà 25T1, Hoàng Đạo Thúy, Trung Hòa, Cầu Giấy, Hà Nội</p>
			</div>
		</div>
	</div>
</footer>