<div class="col-md-6">
	<!-- province -->
	<section class="section province">
		<div class="headline-section">
			<h2><a href="">TỈ LỆ ĐỘI VIÊN THAM GIA RÈN LUYỆN THEO TỈNH/ TP</a></h2>
			<a href="">Xem tất cả</a>
		</div>
		<ul class="province-list">
			<li class="item">
				<div class="number">1</div>
				<div class="progressbar">
					<span>Lai Châu</span>
					<div class="progress">
						<div class="progress-bar" style="width:73.74%"><span>73.74%</span></div>
					</div>
				</div>
			</li>
			<li class="item">
				<div class="number">2</div>
				<div class="progressbar">
					<span>Kom Tum</span>
					<div class="progress">
						<div class="progress-bar" style="width:73.68%"><span>73.%</span></div>
					</div>
				</div>
			</li>
			<li class="item">
				<div class="number">3</div>
				<div class="progressbar">
					<span>Điện biên</span>
					<div class="progress">
						<div class="progress-bar" style="width:46.41%"><span>46.41%</span></div>
					</div>
				</div>
			</li>
			<li class="item">
				<div class="number">4</div>
				<div class="progressbar">
					<span>Bình Định</span>
					<div class="progress">
						<div class="progress-bar" style="width:39.02%"><span>39.02 %</span></div>
					</div>
				</div>
			</li>
			<li class="item">
				<div class="number">5</div>
				<div class="progressbar">
					<span>Hà Nam</span>
					<div class="progress">
						<div class="progress-bar" style="width: 36.15%"><span>36.15 %</span></div>
					</div>
				</div>
			</li>
		</ul>
	</section>
	<!-- province end -->
</div>