<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class NhvvNhanvienNhanvienStar extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::connection('mysql_nhvv')->create('nhvv_nhanvien_nhanvien_star', function (Blueprint $table) {
            $table->increments('id')->index();
            $table->integer('nhanvien_id', false, true);
            $table->integer('star_id', false, true);
            $table->timestamps();
            $table->engine = 'InnoDB';

            $table->foreign('nhanvien_id')->references('nhanvien_id')->on('nhvv_nhanvien')->onDelete('cascade');
            $table->foreign('star_id')->references('star_id')->on('nhvv_nhanvien_star')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::connection('mysql_nhvv')->dropIfExists('nhvv_nhanvien_nhanvien_star');
    }
}
