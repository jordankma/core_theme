<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class NhvvNhanvienThemeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::connection('mysql_nhvv')->create('nhvv_nhanvien_theme', function (Blueprint $table) {
            $table->increments('theme_id');
            $table->string('name');
            $table->tinyInteger('status', false, true)->default(1)->comment('0: disable, 1: enable');
            $table->tinyInteger('visible', false, true)->default(1)->comment('0: invisible, 1: visible');
            $table->timestamps();
            $table->engine = 'InnoDB';
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::connection('mysql_nhvv')->dropIfExists('nhvv_nhanvien_theme');
    }
}
