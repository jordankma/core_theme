<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class NhvvNhanvienTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::connection('mysql_nhvv')->create('nhvv_nhanvien', function (Blueprint $table) {
            $table->increments('nhanvien_id');
            $table->string('name');
            $table->text('description')->comment('mô tả');
            $table->integer('price', false, true)->default(0)->comment('giá bán');
            $table->tinyInteger('type', false, true)->default(0)->comment('0: thường, 1: vip');
            $table->tinyInteger('status', false, true)->default(1)->comment('0: disable, 1: enable');
            $table->tinyInteger('visible', false, true)->default(1);
            $table->timestamps();
            $table->engine = 'InnoDB';
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::connection('mysql_nhvv')->dropIfExists('nhvv_nhanvien');
    }
}
