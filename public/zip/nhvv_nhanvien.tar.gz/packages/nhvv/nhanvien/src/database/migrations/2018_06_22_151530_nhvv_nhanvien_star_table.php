<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class NhvvNhanvienStarTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::connection('mysql_nhvv')->create('nhvv_nhanvien_star', function (Blueprint $table) {
            $table->increments('star_id');
            $table->tinyInteger('star_number', false, true)->default(1);
            $table->tinyInteger('gold_rate', false, true)->default(10);
            $table->tinyInteger('heart_rate', false, true)->default(10);
            $table->tinyInteger('move_rate', false, true)->default(10);
            $table->tinyInteger('gem_rate', false, true)->default(10);
            $table->tinyInteger('status', false, true)->default(1)->comment('0: disable, 1: enable');
            $table->tinyInteger('visible', false, true)->default(1)->comment('0: invisible, 1: visible');
            $table->timestamps();
            $table->engine = 'InnoDB';
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::connection('mysql_nhvv')->dropIfExists('nhvv_nhanvien_star');
    }
}
