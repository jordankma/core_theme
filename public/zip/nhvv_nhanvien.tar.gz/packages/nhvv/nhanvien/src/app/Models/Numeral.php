<?php

namespace Nhvv\Nhanvien\App\Models;

use Illuminate\Database\Eloquent\Model;

class Numeral extends Model {
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $connection = 'mysql_nhvv';
    protected $table = 'nhvv_nhanvien_numeral';
    protected $primaryKey = 'numeral_id';
    protected $guarded = ['numeral_id'];
    protected $fillable = ['name', 'value'];

    public function nhanvien()
    {
        return $this->belongsToMany('Nhvv\Nhanvien\App\Models\Nhanvien', 'nhvv_nhanvien_nhanvien_numeral', 'numeral_id', 'nhanvien_id');
    }
}