<?php

namespace Nhvv\Nhanvien\App\Http\Controllers;

use Illuminate\Http\Request;
use Adtech\Application\Cms\Controllers\Controller as Controller;
use Nhvv\Nhanvien\App\Repositories\ThemeRepository;
use Nhvv\Nhanvien\App\Http\Requests\ThemeRequest;
use Nhvv\Nhanvien\App\Models\Theme;
use Spatie\Activitylog\Models\Activity;
use Yajra\Datatables\Datatables;
use Validator;

class ThemeController extends Controller
{
    private $messages = array(
        'name.regex' => "Sai định dạng",
        'required' => "Bắt buộc",
        'numeric'  => "Phải là số"
    );

    public function __construct(ThemeRepository $themeRepository)
    {
        parent::__construct();
        $this->theme = $themeRepository;
    }

    public function add(ThemeRequest $request)
    {
        $themes = new Theme($request->all());
        $themes->save();

        if ($themes->theme_id) {

            activity('theme')
                ->performedOn($themes)
                ->withProperties($request->all())
                ->log('User: :causer.email - Add Theme - name: :properties.name, theme_id: ' . $themes->theme_id);

            return redirect()->route('nhvv.nhanvien.theme.manage')->with('success', trans('nhvv-nhanvien::language.messages.success.create'));
        } else {
            return redirect()->route('nhvv.nhanvien.theme.manage')->with('error', trans('nhvv-nhanvien::language.messages.error.create'));
        }
    }

    public function create()
    {
        return view('NHVV-NHANVIEN::modules.nhanvien.theme.create');
    }

    public function delete(ThemeRequest $request)
    {
        $theme_id = $request->input('theme_id');
        $theme = $this->theme->find($theme_id);

        if (null != $theme) {
            $this->theme->deleteID($theme_id);

            activity('theme')
                ->performedOn($theme)
                ->withProperties($request->all())
                ->log('User: :causer.email - Delete Theme - theme_id: :properties.theme_id, name: ' . $theme->name);

            return redirect()->route('nhvv.nhanvien.theme.manage')->with('success', trans('nhvv-nhanvien::language.messages.success.delete'));
        } else {
            return redirect()->route('nhvv.nhanvien.theme.manage')->with('error', trans('nhvv-nhanvien::language.messages.error.delete'));
        }
    }

    public function manage()
    {
        return view('NHVV-NHANVIEN::modules.nhanvien.theme.manage');
    }

    public function show(Request $request)
    {
        $theme_id = $request->input('theme_id');
        $theme = $this->theme->find($theme_id);
        $data = [
            'theme' => $theme
        ];

        return view('NHVV-NHANVIEN::modules.nhanvien.theme.edit', $data);
    }

    public function update(ThemeRequest $request)
    {
        $theme_id = $request->input('theme_id');

        $theme = $this->theme->find($theme_id);
        $theme->name = $request->input('name');
        $theme->status = ($request->has('status')) ? 1 : 0;
        if ($theme->save()) {

            activity('theme')
                ->performedOn($theme)
                ->withProperties($request->all())
                ->log('User: :causer.email - Update Theme - theme_id: :properties.theme_id, name: :properties.name');

            return redirect()->route('nhvv.nhanvien.theme.manage')->with('success', trans('nhvv-nhanvien::language.messages.success.update'));
        } else {
            return redirect()->route('nhvv.nhanvien.theme.show', ['theme_id' => $request->input('theme_id')])->with('error', trans('nhvv-nhanvien::language.messages.error.update'));
        }
    }

    public function getModalDelete(Request $request)
    {
        $model = 'theme';
        $confirm_route = $error = null;
        $validator = Validator::make($request->all(), [
            'theme_id' => 'required|numeric',
        ], $this->messages);
        if (!$validator->fails()) {
            try {
                $confirm_route = route('nhvv.nhanvien.theme.delete', ['theme_id' => $request->input('theme_id')]);
                return view('includes.modal_confirmation', compact('error', 'model', 'confirm_route'));
            } catch (GroupNotFoundException $e) {
                return view('includes.modal_confirmation', compact('error', 'model', 'confirm_route'));
            }
        } else {
            return $validator->messages();
        }
    }

    public function log(Request $request)
    {
        $model = 'theme';
        $confirm_route = $error = null;
        $validator = Validator::make($request->all(), [
            'type' => 'required',
            'id' => 'required|numeric',
        ], $this->messages);
        if (!$validator->fails()) {
            try {
                $logs = Activity::where([
                    ['log_name', $model],
                    ['subject_id', $request->input('id')]
                ])->get();
                return view('includes.modal_table', compact('error', 'model', 'confirm_route', 'logs'));
            } catch (GroupNotFoundException $e) {
                return view('includes.modal_table', compact('error', 'model', 'confirm_route'));
            }
        } else {
            return $validator->messages();
        }
    }

    //Table Data to index page
    public function data(Request $request)
    {
        $themes = Theme::where('visible', 1)->get();
        return Datatables::of($themes)
            ->addColumn('actions', function ($themes) {
                $actions = '<a href=' . route('nhvv.nhanvien.theme.log', ['type' => 'theme', 'id' => $themes->theme_id]) . ' data-toggle="modal" data-target="#log"><i class="livicon" data-name="info" data-size="18" data-loop="true" data-c="#F99928" data-hc="#F99928" title="log theme"></i></a>
                        <a href=' . route('nhvv.nhanvien.theme.show', ['theme_id' => $themes->theme_id]) . '><i class="livicon" data-name="edit" data-size="18" data-loop="true" data-c="#428BCA" data-hc="#428BCA" title="update theme"></i></a>
                        <a href=' . route('nhvv.nhanvien.theme.confirm-delete', ['theme_id' => $themes->theme_id]) . ' data-toggle="modal" data-target="#delete_confirm"><i class="livicon" data-name="trash" data-size="18" data-loop="true" data-c="#f56954" data-hc="#f56954" title="delete theme"></i></a>';

                return $actions;
            })
            ->editColumn('status', function ($themes) {
                if ($themes->status == 1) {
                    $status = '<span class="label label-sm label-success">Enable</span>';
                } else {
                    $status = '<span class="label label-sm label-danger">Disable</span>';
                }
                return $status;
            })
            ->rawColumns(['status', 'actions'])
            ->make();
    }
}
