<?php

namespace Nhvv\Nhanvien\App\Http\Controllers;

use function foo\func;
use Illuminate\Http\Request;
use Adtech\Application\Cms\Controllers\Controller as Controller;
use Nhvv\Nhanvien\App\Repositories\StarRepository;
use Nhvv\Nhanvien\App\Http\Requests\StarRequest;
use Nhvv\Nhanvien\App\Models\Star;
use Spatie\Activitylog\Models\Activity;
use Yajra\Datatables\Datatables;
use Validator;

class StarController extends Controller
{
    private $messages = array(
        'name.regex' => "Sai định dạng",
        'required' => "Bắt buộc",
        'numeric'  => "Phải là số"
    );

    public function __construct(StarRepository $starRepository)
    {
        parent::__construct();
        $this->star = $starRepository;
    }

    public function add(StarRequest $request)
    {
        $stars = new Star($request->all());
        $stars->save();

        if ($stars->star_id) {

            activity('star')
                ->performedOn($stars)
                ->withProperties($request->all())
                ->log('User: :causer.email - Add Star - name: :properties.name, star_id: ' . $stars->star_id);

            return redirect()->route('nhvv.nhanvien.star.manage')->with('success', trans('nhvv-nhanvien::language.messages.success.create'));
        } else {
            return redirect()->route('nhvv.nhanvien.star.manage')->with('error', trans('nhvv-nhanvien::language.messages.error.create'));
        }
    }

    public function create()
    {
        return view('NHVV-NHANVIEN::modules.nhanvien.star.create');
    }

    public function delete(ThemeRequest $request)
    {
        $star_id = $request->input('star_id');
        $star = $this->star->find($star_id);

        if (null != $star) {
            $this->star->deleteID($star_id);

            activity('star')
                ->performedOn($star)
                ->withProperties($request->all())
                ->log('User: :causer.email - Delete Star - star_id: :properties.star_id, name: ' . $star->name);

            return redirect()->route('nhvv.nhanvien.star.manage')->with('success', trans('nhvv-nhanvien::language.messages.success.delete'));
        } else {
            return redirect()->route('nhvv.nhanvien.star.manage')->with('error', trans('nhvv-nhanvien::language.messages.error.delete'));
        }
    }

    public function manage()
    {
        return view('NHVV-NHANVIEN::modules.nhanvien.star.manage');
    }

    public function show(Request $request)
    {
        $star_id = $request->input('star_id');
        $star = $this->star->find($star_id);
        $data = [
            'star' => $star
        ];

        return view('NHVV-NHANVIEN::modules.nhanvien.star.edit', $data);
    }

    public function update(StarRequest $request)
    {
        $star_id = $request->input('star_id');

        $star = $this->star->find($star_id);
        $star->star_number = $request->input('star_number');
        $star->gold_rate = $request->input('gold_rate');
        $star->heart_rate = $request->input('heart_rate');
        $star->move_rate = $request->input('move_rate');
        $star->gem_rate = $request->input('gem_rate');
//        $star->status = ($request->has('status')) ? 1 : 0;
        if ($star->save()) {

            activity('star')
                ->performedOn($star)
                ->withProperties($request->all())
                ->log('User: :causer.email - Update Star - star_id: :properties.star_id, name: :properties.name');

            return redirect()->route('nhvv.nhanvien.star.manage')->with('success', trans('nhvv-nhanvien::language.messages.success.update'));
        } else {
            return redirect()->route('nhvv.nhanvien.star.show', ['star_id' => $request->input('star_id')])->with('error', trans('nhvv-nhanvien::language.messages.error.update'));
        }
    }

    public function getModalDelete(Request $request)
    {
        $model = 'star';
        $confirm_route = $error = null;
        $validator = Validator::make($request->all(), [
            'star_id' => 'required|numeric',
        ], $this->messages);
        if (!$validator->fails()) {
            try {
                $confirm_route = route('nhvv.nhanvien.star.delete', ['star_id' => $request->input('star_id')]);
                return view('includes.modal_confirmation', compact('error', 'model', 'confirm_route'));
            } catch (GroupNotFoundException $e) {
                return view('includes.modal_confirmation', compact('error', 'model', 'confirm_route'));
            }
        } else {
            return $validator->messages();
        }
    }

    public function log(Request $request)
    {
        $model = 'star';
        $confirm_route = $error = null;
        $validator = Validator::make($request->all(), [
            'type' => 'required',
            'id' => 'required|numeric',
        ], $this->messages);
        if (!$validator->fails()) {
            try {
                $logs = Activity::where([
                    ['log_name', $model],
                    ['subject_id', $request->input('id')]
                ])->get();
                return view('includes.modal_table', compact('error', 'model', 'confirm_route', 'logs'));
            } catch (GroupNotFoundException $e) {
                return view('includes.modal_table', compact('error', 'model', 'confirm_route'));
            }
        } else {
            return $validator->messages();
        }
    }

    //Table Data to index page
    public function data(Request $request)
    {
        $stars = Star::where('visible', 1)->get();
        return Datatables::of($stars)
            ->addColumn('actions', function ($stars) {
                $actions = '<a href=' . route('nhvv.nhanvien.star.log', ['type' => 'star', 'id' => $stars->star_id]) . ' data-toggle="modal" data-target="#log"><i class="livicon" data-name="info" data-size="18" data-loop="true" data-c="#F99928" data-hc="#F99928" title="log star"></i></a>
                        <a href=' . route('nhvv.nhanvien.star.show', ['star_id' => $stars->star_id]) . '><i class="livicon" data-name="edit" data-size="18" data-loop="true" data-c="#428BCA" data-hc="#428BCA" title="update star"></i></a>
                        <a href=' . route('nhvv.nhanvien.star.confirm-delete', ['star_id' => $stars->star_id]) . ' data-toggle="modal" data-target="#delete_confirm"><i class="livicon" data-name="trash" data-size="18" data-loop="true" data-c="#f56954" data-hc="#f56954" title="delete star"></i></a>';

                return $actions;
            })
            ->editColumn('star_number', function($stars) {
                $star_number = '';
                for ($i = 0; $i < $stars->star_number; $i++) {
                    $star_number .= '<i class="livicon" data-name="star-full" data-size="18" data-loop="true" data-c="#F79838" data-hc="#F79838" title="delete star"></i>';
                }
                return $star_number;
            })
            ->editColumn('status', function ($stars) {
                if ($stars->status == 1) {
                    $status = '<span class="label label-sm label-success">Enable</span>';
                } else {
                    $status = '<span class="label label-sm label-danger">Disable</span>';
                }
                return $status;
            })
            ->rawColumns(['status', 'star_number', 'actions'])
            ->make();
    }
}
