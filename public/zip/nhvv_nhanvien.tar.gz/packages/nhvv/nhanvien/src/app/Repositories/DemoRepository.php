<?php

namespace Nhvv\Nhanvien\App\Repositories;

use Adtech\Application\Cms\Repositories\Eloquent\Repository;

/**
 * Class DemoRepository
 * @package Nhvv\Nhanvien\Repositories
 */
class DemoRepository extends Repository
{

    /**
     * @return string
     */
    public function model()
    {
        return 'Nhvv\Nhanvien\App\Models\Demo';
    }

    public function deleteID($id) {
        return $this->model->where('demo_id', '=', $id)->update(['visible' => 0]);
    }
}