<?php

namespace Nhvv\Nhanvien\App\Repositories;

use Adtech\Application\Cms\Repositories\Eloquent\Repository;

/**
 * Class NhanvienRepository
 * @package Nhvv\Nhanvien\Repositories
 */
class NhanvienRepository extends Repository
{

    /**
     * @return string
     */
    public function model()
    {
        return 'Nhvv\Nhanvien\App\Models\Nhanvien';
    }

    public function deleteID($id) {
        return $this->model->where('nhanvien_id', '=', $id)->update(['visible' => 0]);
    }
}