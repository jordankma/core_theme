<?php

namespace Nhvv\Nhanvien\App\Repositories;

use Adtech\Application\Cms\Repositories\Eloquent\Repository;

/**
 * Class ThemeRepository
 * @package Nhvv\Nhanvien\Repositories
 */
class ThemeRepository extends Repository
{

    /**
     * @return string
     */
    public function model()
    {
        return 'Nhvv\Nhanvien\App\Models\Theme';
    }

    public function deleteID($id) {
        return $this->model->where('theme_id', '=', $id)->update(['visible' => 0]);
    }
}