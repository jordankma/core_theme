<?php

namespace Nhvv\Nhanvien\App\Repositories;

use Adtech\Application\Cms\Repositories\Eloquent\Repository;

/**
 * Class StarRepository
 * @package Nhvv\Nhanvien\Repositories
 */
class StarRepository extends Repository
{

    /**
     * @return string
     */
    public function model()
    {
        return 'Nhvv\Nhanvien\App\Models\Star';
    }

    public function deleteID($id) {
        return $this->model->where('star_id', '=', $id)->update(['visible' => 0]);
    }
}