<?php

namespace Nhvv\Nhanvien\App\Models;

use Illuminate\Database\Eloquent\Model;

class Nhanvien extends Model {
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $connection = 'mysql_nhvv';
    protected $table = 'nhvv_nhanvien';
    protected $primaryKey = 'nhanvien_id';
    protected $guarded = ['nhanvien_id'];
    protected $fillable = ['name', 'type', 'description', 'price'];
}