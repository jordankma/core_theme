<?php

namespace Nhvv\Nhanvien\App\Models;

use Illuminate\Database\Eloquent\Model;

class Theme extends Model {
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $connection = 'mysql_nhvv';
    protected $table = 'nhvv_nhanvien_theme';
    protected $primaryKey = 'theme_id';
    protected $guarded = ['theme_id'];
    protected $fillable = ['name'];

    public function nhanvien()
    {
        return $this->belongsToMany('Nhvv\Nhanvien\App\Models\Nhanvien', 'nhvv_nhanvien_nhanvien_theme', 'theme_id', 'nhanvien_id');
    }
}