<?php

namespace Nhvv\Nhanvien\App\Models;

use Illuminate\Database\Eloquent\Model;
use \Adtech\Application\Cms\Libraries\Acl as AdtechAcl;

class NhanvienTheme extends Model
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $connection = 'mysql_nhvv';
    protected $table = 'nhvv_nhanvien_nhanvien_theme';
    protected $primaryKey = 'id';
    protected $fillable = ['nhanvien_id', 'theme_id'];
}