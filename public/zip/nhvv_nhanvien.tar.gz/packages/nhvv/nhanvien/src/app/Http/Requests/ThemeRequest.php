<?php

namespace Nhvv\Nhanvien\App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ThemeRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        switch ($this->method()) {
            case 'GET':
            case 'DELETE': {
                return [
                    'theme_id' => 'required'
                ];
            }
            case 'POST': {
                return [
                    'name' => 'required'
                ];
            }
            case 'PUT':{
                return [
                    'theme_id' => 'required',
                    'name' => 'required'
                ];
            }
            case 'PATCH':
            default:
                break;
        }
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'required' => 'Bắt buộc',
            'integer' => 'Phải là kiểu số'
        ];
    }
}
