<?php

namespace Nhvv\Nhanvien\App\Http\Controllers;

use Illuminate\Http\Request;
use Adtech\Application\Cms\Controllers\Controller as Controller;
use Nhvv\Nhanvien\App\Models\NhanvienStar;
use Nhvv\Nhanvien\App\Models\NhanvienTheme;
use Nhvv\Nhanvien\App\Models\NhanvienNumeral;
use Nhvv\Nhanvien\App\Repositories\NhanvienRepository;
use Nhvv\Nhanvien\App\Repositories\NhanvienThemeRepository;
use Nhvv\Nhanvien\App\Repositories\NhanvienNumeralRepository;
use Nhvv\Nhanvien\App\Repositories\NhanvienStarRepository;
use Nhvv\Nhanvien\App\Models\Nhanvien;
use Nhvv\Nhanvien\App\Models\Numeral;
use Nhvv\Nhanvien\App\Models\Star;
use Nhvv\Nhanvien\App\Models\Theme;
use Spatie\Activitylog\Models\Activity;
use Yajra\Datatables\Datatables;
use Validator;

class NhanvienController extends Controller
{
    private $messages = array(
        'name.regex' => "Sai định dạng",
        'required' => "Bắt buộc",
        'numeric'  => "Phải là số"
    );

    private $types = array("Thường", "VIP");

    public function __construct(NhanvienRepository $nhanvienRepository, NhanvienStarRepository $nhanvienStarRepository,
                                NhanvienThemeRepository $nhanvienThemeRepository, NhanvienNumeralRepository $nhanvienNumeralRepository)
    {
        parent::__construct();
        $this->nhanvien = $nhanvienRepository;
        $this->nhanvienStar = $nhanvienStarRepository;
        $this->nhanvienTheme = $nhanvienThemeRepository;
        $this->nhanvienNumeral = $nhanvienNumeralRepository;
    }

    public function add(Request $request)
    {
        $nhanviens = new Nhanvien($request->all());
        $nhanviens->save();

        if ($nhanviens->nhanvien_id) {

            activity('nhanvien')
                ->performedOn($nhanviens)
                ->withProperties($request->all())
                ->log('User: :causer.email - Add Nhanvien - name: :properties.name, nhanvien_id: ' . $nhanviens->nhanvien_id);

            return redirect()->route('nhvv.nhanvien.nhanvien.manage')->with('success', trans('nhvv-nhanvien::language.messages.success.create'));
        } else {
            return redirect()->route('nhvv.nhanvien.nhanvien.manage')->with('error', trans('nhvv-nhanvien::language.messages.error.create'));
        }
    }

    public function create()
    {
        $types = $this->types;
        $numerals = Numeral::where('visible', 1)->get();
        $themes = Theme::where('visible', 1)->get();
        $stars = Star::where('visible', 1)->get();

        $data = [
            'types' => $types,
            'themes' => $themes,
            'numerals' => $numerals,
            'stars' => $stars
        ];

        return view('NHVV-NHANVIEN::modules.nhanvien.nhanvien.create', $data);
    }

    public function delete(Request $request)
    {
        $nhanvien_id = $request->input('nhanvien_id');
        $nhanvien = $this->nhanvien->find($nhanvien_id);

        if (null != $nhanvien) {
            $this->nhanvien->deleteID($nhanvien_id);

            activity('nhanvien')
                ->performedOn($nhanvien)
                ->withProperties($request->all())
                ->log('User: :causer.email - Delete Nhanvien - nhanvien_id: :properties.nhanvien_id, name: ' . $nhanvien->name);

            return redirect()->route('nhvv.nhanvien.nhanvien.manage')->with('success', trans('nhvv-nhanvien::language.messages.success.delete'));
        } else {
            return redirect()->route('nhvv.nhanvien.nhanvien.manage')->with('error', trans('nhvv-nhanvien::language.messages.error.delete'));
        }
    }

    public function manage()
    {
        return view('NHVV-NHANVIEN::modules.nhanvien.nhanvien.manage');
    }

    public function show(Request $request)
    {
        $types = $this->types;
        $nhanvien_id = $request->input('nhanvien_id');
        $nhanvien = $this->nhanvien->find($nhanvien_id);

        $numerals = Numeral::where('visible', 1)->get();
        $themes = Theme::where('visible', 1)->get();
        $stars = Star::where('visible', 1)->get();

        $nhanvienStar = $this->nhanvienStar->findWhere([
            'nhanvien_id' => $nhanvien_id
        ]);
        $nhanvienTheme = $this->nhanvienTheme->findWhere([
            'nhanvien_id' => $nhanvien_id
        ]);
        $nhanvienNumeral = $this->nhanvienNumeral->findWhere([
            'nhanvien_id' => $nhanvien_id
        ]);

        $arrStar = $arrTheme = $arrNumeral = array();
        foreach ($nhanvienStar as $star) {
            $arrStar[] = $star->star_id;
        }
        foreach ($nhanvienTheme as $theme) {
            $arrTheme[] = $theme->theme_id;
        }
        foreach ($nhanvienNumeral as $numeral) {
            $arrNumeral[] = $numeral->numeral_id;
        }

        $data = [
            'nhanvien' => $nhanvien,
            'types' => $types,
            'themes' => $themes,
            'numerals' => $numerals,
            'stars' => $stars,
            'arrStar' => $arrStar,
            'arrTheme' => $arrTheme,
            'arrNumeral' => $arrNumeral
        ];


        return view('NHVV-NHANVIEN::modules.nhanvien.nhanvien.edit', $data);
    }

    public function update(Request $request)
    {
        $nhanvien_id = $request->input('nhanvien_id');

        $nhanvien = $this->nhanvien->find($nhanvien_id);
        if (null != $nhanvien) {
            $nhanvien->name = $request->input('name');
            $nhanvien->type = $request->input('type');
            $nhanvien->price = $request->input('price');
            $nhanvien->description = $request->input('description');
            $nhanvien->status = ($request->has('status')) ? 1 : 0;
            if ($nhanvien->save()) {

                NhanvienStar::where('nhanvien_id', $nhanvien_id)->delete();
                NhanvienTheme::where('nhanvien_id', $nhanvien_id)->delete();
                NhanvienNumeral::where('nhanvien_id', $nhanvien_id)->delete();

                if ($request->has('stars')) {
                    $stars = $request->input('stars');
//                    $nhanvienStar = $this->nhanvienStar->findWhere([
//                        'nhanvien_id' => $nhanvien_id,
//                        'star_id' => $stars
//                    ]);
                    $nhanvienStar = new NhanvienStar();
                    $nhanvienStar->nhanvien_id = $nhanvien_id;
                    $nhanvienStar->star_id = $stars;
                    $nhanvienStar->save();
                }

                if ($request->has('themes')) {
                    $themes = $request->input('themes');
                    if (count($themes) > 0) {
                        foreach ($themes as $key=>$theme_id) {
                            $nhanvienTheme = new NhanvienTheme();
                            $nhanvienTheme->nhanvien_id = $nhanvien_id;
                            $nhanvienTheme->theme_id = $theme_id;
                            $nhanvienTheme->save();
                        }
                    }
                }

                if ($request->has('numerals')) {
                    $numerals = $request->input('numerals');
                    if (count($numerals) > 0) {
                        foreach ($numerals as $key => $numeral_id) {
                            $nhanvienNumeral = new NhanvienNumeral();
                            $nhanvienNumeral->nhanvien_id = $nhanvien_id;
                            $nhanvienNumeral->numeral_id = $numeral_id;
                            $nhanvienNumeral->save();
                        }
                    }
                }

                activity('nhanvien')
                    ->performedOn($nhanvien)
                    ->withProperties($request->all())
                    ->log('User: :causer.email - Update nhanvien - nhanvien_id: :properties.nhanvien_id, name: :properties.name');

                return redirect()->route('nhvv.nhanvien.nhanvien.manage')->with('success', trans('nhvv-nhanvien::language.messages.success.update'));
            } else {
                return redirect()->route('nhvv.nhanvien.nhanvien.show', ['nhanvien_id' => $request->input('nhanvien_id')])->with('error', trans('nhvv-nhanvien::language.messages.error.update'));
            }
        } else {
            return redirect()->route('nhvv.nhanvien.nhanvien.show', ['nhanvien_id' => $request->input('nhanvien_id')])->with('error', trans('nhvv-nhanvien::language.messages.error.update'));
        }

    }

    public function getModalDelete(Request $request)
    {
        $model = 'nhanvien';
        $confirm_route = $error = null;
        $validator = Validator::make($request->all(), [
            'nhanvien_id' => 'required|numeric',
        ], $this->messages);
        if (!$validator->fails()) {
            try {
                $confirm_route = route('nhvv.nhanvien.nhanvien.delete', ['nhanvien_id' => $request->input('nhanvien_id')]);
                return view('includes.modal_confirmation', compact('error', 'model', 'confirm_route'));
            } catch (GroupNotFoundException $e) {
                return view('includes.modal_confirmation', compact('error', 'model', 'confirm_route'));
            }
        } else {
            return $validator->messages();
        }
    }

    public function log(Request $request)
    {
        $model = 'nhanvien';
        $confirm_route = $error = null;
        $validator = Validator::make($request->all(), [
            'type' => 'required',
            'id' => 'required|numeric',
        ], $this->messages);
        if (!$validator->fails()) {
            try {
                $logs = Activity::where([
                    ['log_name', $model],
                    ['subject_id', $request->input('id')]
                ])->get();
                return view('includes.modal_table', compact('error', 'model', 'confirm_route', 'logs'));
            } catch (GroupNotFoundException $e) {
                return view('includes.modal_table', compact('error', 'model', 'confirm_route'));
            }
        } else {
            return $validator->messages();
        }
    }

    //Table Data to index page
    public function data(Request $request)
    {
        $nhanviens = Nhanvien::where('visible', 1)->get();
        return Datatables::of($nhanviens)
            ->addColumn('actions', function ($nhanviens) {
                $actions = '<a href=' . route('nhvv.nhanvien.nhanvien.log', ['type' => 'nhanvien', 'id' => $nhanviens->nhanvien_id]) . ' data-toggle="modal" data-target="#log"><i class="livicon" data-name="info" data-size="18" data-loop="true" data-c="#F99928" data-hc="#F99928" title="log nhanvien"></i></a>
                        <a href=' . route('nhvv.nhanvien.nhanvien.show', ['nhanvien_id' => $nhanviens->nhanvien_id]) . '><i class="livicon" data-name="edit" data-size="18" data-loop="true" data-c="#428BCA" data-hc="#428BCA" title="update nhanvien"></i></a>
                        <a href=' . route('nhvv.nhanvien.nhanvien.confirm-delete', ['nhanvien_id' => $nhanviens->nhanvien_id]) . ' data-toggle="modal" data-target="#delete_confirm"><i class="livicon" data-name="trash" data-size="18" data-loop="true" data-c="#f56954" data-hc="#f56954" title="delete nhanvien"></i></a>';

                return $actions;
            })
            ->editColumn('status', function ($nhanviens) {
                if ($nhanviens->status == 1) {
                    $status = '<span class="label label-sm label-success">Enable</span>';
                } else {
                    $status = '<span class="label label-sm label-danger">Disable</span>';
                }
                return $status;
            })
            ->rawColumns(['status', 'actions'])
            ->make();
    }
}
