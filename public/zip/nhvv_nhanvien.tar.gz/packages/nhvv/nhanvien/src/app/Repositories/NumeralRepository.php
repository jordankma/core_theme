<?php

namespace Nhvv\Nhanvien\App\Repositories;

use Adtech\Application\Cms\Repositories\Eloquent\Repository;

/**
 * Class NumeralRepository
 * @package Nhvv\Nhanvien\Repositories
 */
class NumeralRepository extends Repository
{

    /**
     * @return string
     */
    public function model()
    {
        return 'Nhvv\Nhanvien\App\Models\Numeral';
    }

    public function deleteID($id) {
        return $this->model->where('numeral_id', '=', $id)->update(['visible' => 0]);
    }
}