<?php

namespace Nhvv\Nhanvien\App\Models;

use Illuminate\Database\Eloquent\Model;

class Star extends Model {
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $connection = 'mysql_nhvv';
    protected $table = 'nhvv_nhanvien_star';
    protected $primaryKey = 'star_id';
    protected $guarded = ['star_id'];
    protected $fillable = ['star_number', 'gold_rate', 'heart_rate', 'move_rate', 'gem_rate'];

    public function nhanvien()
    {
        return $this->belongsToMany('Nhvv\Nhanvien\App\Models\Nhanvien', 'nhvv_nhanvien_nhanvien_star', 'star_id', 'nhanvien_id');
    }
}