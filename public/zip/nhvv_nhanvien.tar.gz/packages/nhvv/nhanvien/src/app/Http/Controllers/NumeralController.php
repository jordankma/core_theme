<?php

namespace Nhvv\Nhanvien\App\Http\Controllers;

use Illuminate\Http\Request;
use Adtech\Application\Cms\Controllers\Controller as Controller;
use Nhvv\Nhanvien\App\Repositories\NumeralRepository;
use Nhvv\Nhanvien\App\Http\Requests\NumeralRequest;
use Nhvv\Nhanvien\App\Models\Numeral;
use Spatie\Activitylog\Models\Activity;
use Yajra\Datatables\Datatables;
use Validator;

class NumeralController extends Controller
{
    private $messages = array(
        'name.regex' => "Sai định dạng",
        'required' => "Bắt buộc",
        'numeric'  => "Phải là số"
    );

    public function __construct(NumeralRepository $numeralRepository)
    {
        parent::__construct();
        $this->numeral = $numeralRepository;
    }

    public function add(NumeralRequest $request)
    {
        $numerals = new Numeral($request->all());
        $numerals->save();

        if ($numerals->numeral_id) {

            activity('numeral')
                ->performedOn($numerals)
                ->withProperties($request->all())
                ->log('User: :causer.email - Add Numeral - name: :properties.name, numeral_id: ' . $numerals->numeral_id);

            return redirect()->route('nhvv.nhanvien.numeral.manage')->with('success', trans('nhvv-nhanvien::language.messages.success.create'));
        } else {
            return redirect()->route('nhvv.nhanvien.numeral.manage')->with('error', trans('nhvv-nhanvien::language.messages.error.create'));
        }
    }

    public function create()
    {
        return view('NHVV-NHANVIEN::modules.nhanvien.numeral.create');
    }

    public function delete(NumeralRequest $request)
    {
        $numeral_id = $request->input('numeral_id');
        $numeral = $this->numeral->find($numeral_id);

        if (null != $numeral) {
            $this->numeral->deleteID($numeral_id);

            activity('numeral')
                ->performedOn($numeral)
                ->withProperties($request->all())
                ->log('User: :causer.email - Delete Numeral - numeral_id: :properties.numeral_id, name: ' . $numeral->name);

            return redirect()->route('nhvv.nhanvien.numeral.manage')->with('success', trans('nhvv-nhanvien::language.messages.success.delete'));
        } else {
            return redirect()->route('nhvv.nhanvien.numeral.manage')->with('error', trans('nhvv-nhanvien::language.messages.error.delete'));
        }
    }

    public function manage()
    {
        return view('NHVV-NHANVIEN::modules.nhanvien.numeral.manage');
    }

    public function show(Request $request)
    {
        $numeral_id = $request->input('numeral_id');
        $numeral = $this->numeral->find($numeral_id);
        $data = [
            'numeral' => $numeral
        ];

        return view('NHVV-NHANVIEN::modules.nhanvien.numeral.edit', $data);
    }

    public function update(NumeralRequest $request)
    {
        $numeral_id = $request->input('numeral_id');

        $numeral = $this->numeral->find($numeral_id);
        $numeral->name = $request->input('name');
        $numeral->value = $request->input('value');
        $numeral->status = ($request->has('status')) ? 1 : 0;
        if ($numeral->save()) {

            activity('numeral')
                ->performedOn($numeral)
                ->withProperties($request->all())
                ->log('User: :causer.email - Update Numeral - numeral_id: :properties.numeral_id, name: :properties.name');

            return redirect()->route('nhvv.nhanvien.numeral.manage')->with('success', trans('nhvv-nhanvien::language.messages.success.update'));
        } else {
            return redirect()->route('nhvv.nhanvien.numeral.show', ['numeral_id' => $request->input('numeral_id')])->with('error', trans('nhvv-nhanvien::language.messages.error.update'));
        }
    }

    public function getModalDelete(Request $request)
    {
        $model = 'numeral';
        $confirm_route = $error = null;
        $validator = Validator::make($request->all(), [
            'numeral_id' => 'required|numeric',
        ], $this->messages);
        if (!$validator->fails()) {
            try {
                $confirm_route = route('nhvv.nhanvien.numeral.delete', ['numeral_id' => $request->input('numeral_id')]);
                return view('includes.modal_confirmation', compact('error', 'model', 'confirm_route'));
            } catch (GroupNotFoundException $e) {
                return view('includes.modal_confirmation', compact('error', 'model', 'confirm_route'));
            }
        } else {
            return $validator->messages();
        }
    }

    public function log(Request $request)
    {
        $model = 'numeral';
        $confirm_route = $error = null;
        $validator = Validator::make($request->all(), [
            'type' => 'required',
            'id' => 'required|numeric',
        ], $this->messages);
        if (!$validator->fails()) {
            try {
                $logs = Activity::where([
                    ['log_name', $model],
                    ['subject_id', $request->input('id')]
                ])->get();
                return view('includes.modal_table', compact('error', 'model', 'confirm_route', 'logs'));
            } catch (GroupNotFoundException $e) {
                return view('includes.modal_table', compact('error', 'model', 'confirm_route'));
            }
        } else {
            return $validator->messages();
        }
    }

    //Table Data to index page
    public function data(Request $request)
    {
        $numerals = Numeral::where('visible', 1)->get();
        return Datatables::of($numerals)
            ->addColumn('actions', function ($numerals) {
                $actions = '<a href=' . route('nhvv.nhanvien.numeral.log', ['type' => 'numeral', 'id' => $numerals->numeral_id]) . ' data-toggle="modal" data-target="#log"><i class="livicon" data-name="info" data-size="18" data-loop="true" data-c="#F99928" data-hc="#F99928" title="log numeral"></i></a>
                        <a href=' . route('nhvv.nhanvien.numeral.show', ['numeral_id' => $numerals->numeral_id]) . '><i class="livicon" data-name="edit" data-size="18" data-loop="true" data-c="#428BCA" data-hc="#428BCA" title="update numeral"></i></a>
                        <a href=' . route('nhvv.nhanvien.numeral.confirm-delete', ['numeral_id' => $numerals->numeral_id]) . ' data-toggle="modal" data-target="#delete_confirm"><i class="livicon" data-name="trash" data-size="18" data-loop="true" data-c="#f56954" data-hc="#f56954" title="delete numeral"></i></a>';

                return $actions;
            })
            ->editColumn('status', function ($numerals) {
                if ($numerals->status == 1) {
                    $status = '<span class="label label-sm label-success">Enable</span>';
                } else {
                    $status = '<span class="label label-sm label-danger">Disable</span>';
                }
                return $status;
            })
            ->rawColumns(['status', 'actions'])
            ->make();
    }
}
