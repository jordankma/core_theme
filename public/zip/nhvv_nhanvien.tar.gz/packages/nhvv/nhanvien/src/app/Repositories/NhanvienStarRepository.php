<?php

namespace Nhvv\Nhanvien\App\Repositories;

use Adtech\Application\Cms\Repositories\Eloquent\Repository;

class NhanvienStarRepository extends Repository
{
    /**
     * @return string
     */
    public function model()
    {
        return 'Nhvv\Nhanvien\App\Models\NhanvienStar';
    }
}