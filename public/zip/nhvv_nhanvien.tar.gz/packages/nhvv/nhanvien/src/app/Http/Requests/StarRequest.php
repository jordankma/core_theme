<?php

namespace Nhvv\Nhanvien\App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StarRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        switch ($this->method()) {
            case 'GET':
            case 'DELETE': {
                return [
                    'star_id' => 'required'
                ];
            }
            case 'POST': {
                return [
                    'star_number' => 'required|integer|min:1|max:5',
                    'gold_rate' => 'required|integer|min:0|max:100',
                    'heart_rate' => 'required|integer|min:0|max:100',
                    'move_rate' => 'required|integer|min:0|max:100',
                    'gem_rate' => 'required|integer|min:0|max:100'
                ];
            }
            case 'PUT':{
                return [
                    'star_id' => 'required',
                    'star_number' => 'required|integer|min:1|max:5',
                    'gold_rate' => 'required|integer|min:0|max:100',
                    'heart_rate' => 'required|integer|min:0|max:100',
                    'move_rate' => 'required|integer|min:0|max:100',
                    'gem_rate' => 'required|integer|min:0|max:100'
                ];
            }
            case 'PATCH':
            default:
                break;
        }
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'required' => 'Bắt buộc',
            'integer' => 'Phải là kiểu số'
        ];
    }
}
