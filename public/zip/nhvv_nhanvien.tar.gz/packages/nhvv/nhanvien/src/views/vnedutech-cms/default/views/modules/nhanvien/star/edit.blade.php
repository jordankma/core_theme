@extends('layouts.default')

{{-- Page title --}}
@section('title'){{ $title = trans('nhvv-nhanvien::language.titles.star.update') }}@stop

{{-- page styles --}}
@section('header_styles')
    <link href="{{ asset('/vendor/' . $group_name . '/' . $skin . '/css/pages/blog.css') }}" rel="stylesheet" type="text/css">
    <!--end of page css-->
@stop


{{-- Page content --}}
@section('content')
    <section class="content-header">
        <h1>{{ $title }}</h1>
        <ol class="breadcrumb">
            <li>
                <a href="{{ route('backend.homepage') }}"> <i class="livicon" data-name="home" data-size="16"
                                                                         data-color="#000"></i>
                    {{ trans('adtech-core::labels.home') }}
                </a>
            </li>
            <li class="active"><a href="#">{{ $title }}</a></li>
        </ol>
    </section>
    <!--section ends-->
    <section class="content paddingleft_right15">
        <!--main content-->
        <div class="row">
            <div class="the-box no-border">
                {!! Form::model($star, ['url' => route('nhvv.nhanvien.star.update'), 'method' => 'put', 'class' => 'bf form-horizontal', 'id' => 'starForm', 'files'=> true]) !!}
                <div class="row">
                    <div class="col-sm-8">

                        <div class="form-group">
                            <label class="col-md-2 control-label">Star Name</label>
                            <div class="col-md-10 form-group {{ $errors->first('star_number', 'has-error') }}">
                                {!! Form::text('star_number', null, array('class' => 'form-control', 'autofocus'=>'autofocus', 'min' => 1, 'max' => 5,
                                'placeholder'=>trans('nhvv-nhanvien::language.placeholder.star.number_here'))) !!}
                                <span class="help-block">{{ $errors->first('star_number', ':message') }}</span>
                            </div>

                            <label class="col-md-2 control-label">Gold Rate</label>
                            <div class="col-md-10 form-group {{ $errors->first('gold_rate', 'has-error') }}">
                                {!! Form::number('gold_rate', null, array('min' => 0, 'max' => 100, 'class' => 'form-control', 'placeholder'=> trans('nhvv-nhanvien::language.placeholder.star.gold_rate'))) !!}
                                <span class="help-block">{{ $errors->first('gold_rate', ':message') }}</span>
                            </div>

                            <label class="col-md-2 control-label">Heart Rate</label>
                            <div class="col-md-10 form-group {{ $errors->first('heart_rate', 'has-error') }}">
                                {!! Form::number('heart_rate', null, array('min' => 0, 'max' => 100, 'class' => 'form-control', 'placeholder'=> trans('nhvv-nhanvien::language.placeholder.star.heart_rate'))) !!}
                                <span class="help-block">{{ $errors->first('heart_rate', ':message') }}</span>
                            </div>

                            <label class="col-md-2 control-label">Move Rate</label>
                            <div class="col-md-10 form-group {{ $errors->first('move_rate', 'has-error') }}">
                                {!! Form::number('move_rate', null, array('min' => 0, 'max' => 100, 'class' => 'form-control', 'placeholder'=> trans('nhvv-nhanvien::language.placeholder.star.move_rate'))) !!}
                                <span class="help-block">{{ $errors->first('move_rate', ':message') }}</span>
                            </div>

                            <label class="col-md-2 control-label">Gem Rate</label>
                            <div class="col-md-10 form-group {{ $errors->first('gem_rate', 'has-error') }}">
                                {!! Form::number('gem_rate', null, array('min' => 0, 'max' => 100, 'class' => 'form-control', 'placeholder'=> trans('nhvv-nhanvien::language.placeholder.star.gem_rate'))) !!}
                                <span class="help-block">{{ $errors->first('gem_rate', ':message') }}</span>
                            </div>
                        </div>

                        <div class="form-group">
                            {!! Form::hidden('star_id') !!}
                        </div>
                        <div class="form-position">
                            <div class="col-md-12 text-right">
                                <button type="submit" class="btn btn-success">{{ trans('adtech-core::buttons.save') }}</button>
                                <a href="{!! route('nhvv.nhanvien.star.manage') !!}"
                                   class="btn btn-danger">{{ trans('nhvv-nhanvien::language.buttons.discard') }}</a>
                            </div>
                        </div>
                    </div>
                    <!-- /.col-sm-8 -->
                    <div class="col-sm-4">

                    </div>
                    <!-- /.col-sm-4 --> </div>
                <!-- /.row -->
                {!! Form::close() !!}
            </div>
        </div>
        <!--main content ends-->
    </section>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <!-- begining of page js -->
@stop
