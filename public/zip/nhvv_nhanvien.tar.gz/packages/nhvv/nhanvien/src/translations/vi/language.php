<?php

return [
    "titles" => [
        "nhanvien" => [
            "manage" => "Quản lý nhân viên",
            "create" => "Thêm nhân viên",
            "update" => "Cập nhật nhân viên",
        ],
        "theme" => [
            "manage" => "Manage theme",
            "create" => "Create theme",
            "update" => "Update theme",
        ],
        "star" => [
            "manage" => "Manage star",
            "create" => "Create star",
            "update" => "Update star",
        ],
        "numeral" => [
            "manage" => "Manage numeral",
            "create" => "Create numeral",
            "update" => "Update numeral",
        ]
    ],
    "table" => [
        "id" => "#",
        "created_at" => "Created at",
        "updated_at" => "Updated at",
        "action" => "Actions",
        "status" => "Status",
        "nhanvien" => [
            "name" => "Name"
        ],
        "theme" => [
            "name" => "Name"
        ],
        "numeral" => [
            "name" => "Name",
            "value" => "Value",
        ],
        "star" => [
            "number" => "Star Number",
            "gold" => "Gold Rate",
            "heart" => "Heart Rate",
            "move" => "Move Rate",
            "gem" => "Gem Rate"
        ]
    ],
    "buttons" => [
        "create" => "Create",
        "discard" => "Discard"
    ],
    "placeholder" => [
        "nhanvien" => [
            "name_here" => "Name here...",
            "price_here" => "Price here...",
            "description_here" => "Description here..."
        ],
        "theme" => [
            "name_here" => "Name here..."
        ],
        "numeral" => [
            "name_here" => "Name here...",
            "value_here" => "Value numeral here..."
        ],
        "star" => [
            "number_here" => "Star number here...",
            "gold_rate" => "Gold rate here...",
            "heart_rate" => "Heart rate here...",
            "move_rate" => "Move rate here...",
            "gem_rate" => "Gem rate here...",
        ]
    ],
    "messages" => [
        "success" => [
            "create" => "Create successfully",
            "update" => "Update successfully",
            "delete" => "Delete successfully"
        ],
        "error" => [
            "permission" => "Permission lock",
            "create" => "Create failed",
            "update" => "Update failed",
            "delete" => "Delete failed"
        ]
    ]
];