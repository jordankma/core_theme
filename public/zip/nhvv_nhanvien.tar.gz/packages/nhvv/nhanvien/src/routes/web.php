<?php
$adminPrefix = config('site.admin_prefix');
Route::group(array('prefix' => $adminPrefix), function() {
    Route::group(['middleware' => ['adtech.auth', 'adtech.acl']], function () {

        Route::get('nhvv/nhanvien/nhanvien/log', 'NhanvienController@log')->name('nhvv.nhanvien.nhanvien.log');
        Route::get('nhvv/nhanvien/nhanvien/data', 'NhanvienController@data')->name('nhvv.nhanvien.nhanvien.data');
        Route::get('nhvv/nhanvien/nhanvien/manage', 'NhanvienController@manage')->name('nhvv.nhanvien.nhanvien.manage');
        Route::get('nhvv/nhanvien/nhanvien/create', 'NhanvienController@create')->name('nhvv.nhanvien.nhanvien.create');
        Route::post('nhvv/nhanvien/nhanvien/add', 'NhanvienController@add')->name('nhvv.nhanvien.nhanvien.add');
        Route::get('nhvv/nhanvien/nhanvien/show', 'NhanvienController@show')->name('nhvv.nhanvien.nhanvien.show');
        Route::put('nhvv/nhanvien/nhanvien/update', 'NhanvienController@update')->name('nhvv.nhanvien.nhanvien.update');
        Route::get('nhvv/nhanvien/nhanvien/delete', 'NhanvienController@delete')->name('nhvv.nhanvien.nhanvien.delete');
        Route::get('nhvv/nhanvien/nhanvien/confirm-delete', 'NhanvienController@getModalDelete')->name('nhvv.nhanvien.nhanvien.confirm-delete');
        
        Route::get('nhvv/nhanvien/theme/log', 'ThemeController@log')->name('nhvv.nhanvien.theme.log');
        Route::get('nhvv/nhanvien/theme/data', 'ThemeController@data')->name('nhvv.nhanvien.theme.data');
        Route::get('nhvv/nhanvien/theme/manage', 'ThemeController@manage')->name('nhvv.nhanvien.theme.manage');
        Route::get('nhvv/nhanvien/theme/create', 'ThemeController@create')->name('nhvv.nhanvien.theme.create');
        Route::post('nhvv/nhanvien/theme/add', 'ThemeController@add')->name('nhvv.nhanvien.theme.add');
        Route::get('nhvv/nhanvien/theme/show', 'ThemeController@show')->name('nhvv.nhanvien.theme.show');
        Route::put('nhvv/nhanvien/theme/update', 'ThemeController@update')->name('nhvv.nhanvien.theme.update');
        Route::get('nhvv/nhanvien/theme/delete', 'ThemeController@delete')->name('nhvv.nhanvien.theme.delete');
        Route::get('nhvv/nhanvien/theme/confirm-delete', 'ThemeController@getModalDelete')->name('nhvv.nhanvien.theme.confirm-delete');
        
        Route::get('nhvv/nhanvien/star/log', 'StarController@log')->name('nhvv.nhanvien.star.log');
        Route::get('nhvv/nhanvien/star/data', 'StarController@data')->name('nhvv.nhanvien.star.data');
        Route::get('nhvv/nhanvien/star/manage', 'StarController@manage')->name('nhvv.nhanvien.star.manage');
        Route::get('nhvv/nhanvien/star/create', 'StarController@create')->name('nhvv.nhanvien.star.create');
        Route::post('nhvv/nhanvien/star/add', 'StarController@add')->name('nhvv.nhanvien.star.add');
        Route::get('nhvv/nhanvien/star/show', 'StarController@show')->name('nhvv.nhanvien.star.show');
        Route::put('nhvv/nhanvien/star/update', 'StarController@update')->name('nhvv.nhanvien.star.update');
        Route::get('nhvv/nhanvien/star/delete', 'StarController@delete')->name('nhvv.nhanvien.star.delete');
        Route::get('nhvv/nhanvien/star/confirm-delete', 'StarController@getModalDelete')->name('nhvv.nhanvien.star.confirm-delete');
        
        Route::get('nhvv/nhanvien/numeral/log', 'NumeralController@log')->name('nhvv.nhanvien.numeral.log');
        Route::get('nhvv/nhanvien/numeral/data', 'NumeralController@data')->name('nhvv.nhanvien.numeral.data');
        Route::get('nhvv/nhanvien/numeral/manage', 'NumeralController@manage')->name('nhvv.nhanvien.numeral.manage');
        Route::get('nhvv/nhanvien/numeral/create', 'NumeralController@create')->name('nhvv.nhanvien.numeral.create');
        Route::post('nhvv/nhanvien/numeral/add', 'NumeralController@add')->name('nhvv.nhanvien.numeral.add');
        Route::get('nhvv/nhanvien/numeral/show', 'NumeralController@show')->name('nhvv.nhanvien.numeral.show');
        Route::put('nhvv/nhanvien/numeral/update', 'NumeralController@update')->name('nhvv.nhanvien.numeral.update');
        Route::get('nhvv/nhanvien/numeral/delete', 'NumeralController@delete')->name('nhvv.nhanvien.numeral.delete');
        Route::get('nhvv/nhanvien/numeral/confirm-delete', 'NumeralController@getModalDelete')->name('nhvv.nhanvien.numeral.confirm-delete');
    });
});