<?php

namespace Dhcd\Api\App\Http\Controllers\Traits;

use Dhcd\Document\App\Models\Document as DocModel;
use Dhcd\Document\App\Models\DocumentCate;
use Validator;
use Cache;

trait Document
{
    public function getMenuDocument()
    {
        Cache::forget('api_document_cate');
        if (Cache::has('api_document_cate')) {
            $menus = Cache::get('api_document_cate');
        } else {
            $menus = app('Dhcd\Document\App\Http\Controllers\DocumentCateController')->getListCategory();
            $expiresAt = now()->addMinutes(3600);
            Cache::put('api_document_cate', $menus, $expiresAt);
        }

        $list_menus = [];
        if (count($menus) > 0) {
            foreach ($menus as $menu) {
                $menu = (object) $menu;
                $item = new \stdClass();
                $item->id = $menu->document_cate_id;
                $item->title = $menu->name;
                $item->alias = $menu->alias;
                $item->type = 1;
                $item->type_api = 1;
                $item->icon = config('site.url_storage') . $menu->icon;
                $list_menus[] = $item;
            }
        }

        $data = '{
                    "data": {
                        "list_info_item_menu": '. json_encode($list_menus) .'
                    },
                    "success" : true,
                    "message" : "ok!"
                }';
        return response($data)->setStatusCode(200)->header('Content-Type', 'application/json; charset=utf-8');
    }

    public function getFilesDocument($request) {
        $page = $request->input('page', 1);
        $alias = $request->input('alias', '');
        $list_news = $filesDoc = [];

        Cache::forget('api_doc_document_page_' . $alias . '_' . $page);
        if (Cache::has('api_doc_document_page_' . $alias . '_' . $page)) {
            $filesDoc = Cache::get('api_doc_document_page_' . $alias . '_' . $page);
        } else {
            $documentCate = DocumentCate::where('alias', $alias)->first();
            if (null != $documentCate) {
                $filesDoc = DocModel::with('getDocumentCate')
                    ->whereHas('getDocumentCate', function ($query) use ($documentCate) {
                        $query->where('dhcd_document_has_cate.document_cate_id', $documentCate->document_cate_id);
                    })->paginate(10);

                $expiresAt = now()->addMinutes(3600);
                Cache::put('api_doc_document_page_' . $alias . '_' . $page, $filesDoc, $expiresAt);
            }

        }

        if (count($filesDoc) > 0) {
            foreach ($filesDoc as $file) {
                $item = new \stdClass();
                $listFiles = json_decode($file->file, true);
                if (count($listFiles) > 0) {
                    $listFile = [];
                    foreach ($listFiles as $files) {
                        $files['name'] = (self::is_url($files['name'])) ? $files['name'] : config('app.url') . '' . $files['name'];
                        $listFile[] = $files;
                    }

                    $item->id = $file->document_id;
                    $item->title = base64_encode($file->name);
                    $item->alias = base64_encode($file->alias);
                    $item->sub_title = base64_encode($file->descript);
                    $item->icon = (self::is_url($file->avatar)) ? $file->avatar : config('app.url') . '' . $file->avatar;
                    $item->files = $listFile;
                    $item->type_file = '';
                    $item->date_created = date_format($file->created_at, 'Y-m-d');
                    $item->date_modified = date_format($file->updated_at, 'Y-m-d');

                    $list_news[] = $item;
                }
                //
            }
        }

        $data = '{
                    "data": {
                        "list_document": '. json_encode($list_news) .',
                        "total_page": ' . $filesDoc->lastPage() . ',
                        "current_page": '. $page .'
                    },
                    "success" : true,
                    "message" : "ok!"
                }';
        return response($data)->setStatusCode(200)->header('Content-Type', 'application/json; charset=utf-8');
    }

    public function getFilesDetail($request) {
        $alias = $request->input('alias', '');
        Cache::forget('api_doc_document_detail_' . $alias);
        if (Cache::has('api_doc_document_detail_' . $alias)) {
            $filesDoc = Cache::get('api_doc_document_detail_' . $alias);
        } else {
            $filesDoc = DocModel::where('alias', $alias)->first();
            $expiresAt = now()->addMinutes(3600);
            Cache::put('api_doc_document_detail_' . $alias, $filesDoc, $expiresAt);
        }

        $item = new \stdClass();
        if (null != $filesDoc) {
            
                $listFiles = json_decode($filesDoc->file, true);
                if (count($listFiles) > 0) {
                    $listFile = [];
                    foreach ($listFiles as $files) {
                        $files['name'] = (self::is_url($files['name'])) ? $files['name'] : config('app.url') . '' . $files['name'];
                        $listFile[] = $files;
                    }

                    $item->id = $filesDoc->document_id;
                    $item->title = base64_encode($filesDoc->name);
                    $item->alias = base64_encode($filesDoc->alias);
                    $item->sub_title = base64_encode($filesDoc->descript);
                    $item->icon = (self::is_url($filesDoc->avatar)) ? $filesDoc->avatar : config('app.url') . '' . $filesDoc->avatar;
                    $item->files = $listFile;
                    $item->type_file = '';
                    $item->date_created = date_format($filesDoc->created_at, 'Y-m-d');
                    $item->date_modified = date_format($filesDoc->updated_at, 'Y-m-d');
                }
                //
        }

        $data = '{
                    "data": '. json_encode($item) .',
                    "success" : true,
                    "message" : "ok!"
                }';
        return response($data)->setStatusCode(200)->header('Content-Type', 'application/json; charset=utf-8');
    }
}