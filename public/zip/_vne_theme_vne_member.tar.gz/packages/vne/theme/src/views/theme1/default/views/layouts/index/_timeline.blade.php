<div class="col-12">
				<section class="section timeline">
					<h2 class="headline"><a href="">Timeline cuộc thi</a></h2>
					<ul class="timeline-list">
						<li class="item">
							<div class="inner">
								<div class="title">Tuần 1</div>
								<div class="date">02/10 - 08/10</div>
							</div>
						</li>
						<li class="item">
							<div class="inner">
								<div class="title">Tuần 2</div>
								<div class="date">09/10 - 15/10</div>
							</div>
						</li>
						<li class="item">
							<div class="inner">
								<div class="title">Tuần 3</div>
								<div class="date">16/10 - 22/10</div>
							</div>
						</li>
						<li class="item">
							<div class="inner">
								<div class="title">Tuần 4</div>
								<div class="date">23/10 - 29/10</div>
							</div>
						</li>
						<li class="item">
							<div class="inner">
								<div class="title">Tuần 5</div>
								<div class="date">30/10 - 05/11</div>
							</div>
						</li>
						<li class="item">
							<div class="inner">
								<div class="title">Tuần 6</div>
								<div class="date">06/11 - 12/11</div>
							</div>
						</li>
						<li class="item">
							<div class="inner">
								<div class="title">Vòng thi cấp tỉnh/TP</div>
								<div class="date">27/11 - 30/11</div>
							</div>
						</li>
					</ul>
					<div class="info">
						<div class="user user-registration">
							<img src="{{ asset('/vendor/' . $group_name . '/' . $skin . '/src/images/cup2.png?t=' . time()) }}" alt="">
							<div class="number">233.657</div>
							<div class="title">THÍ SINH ĐĂNG KÝ</div>
						</div>
						<div class="user user-active">
							<img src="{{ asset('/vendor/' . $group_name . '/' . $skin . '/src/images/flag.png?t=' . time()) }}" alt="">
							<div class="number">197.998</div>
							<div class="title">THÍ SINH ĐÃ THI</div>
						</div>
					</div>
				</section>
			</div>