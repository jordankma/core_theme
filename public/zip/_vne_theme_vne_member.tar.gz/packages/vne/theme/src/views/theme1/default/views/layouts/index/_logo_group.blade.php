<div class="col-12">
				<!-- logo list -->
				<section class="section logo-group">
					<div class="logo-list">
						<h2 class="title">Ban tổ chức cuộc thi</h2>
						<div class="carousel js-carousel-01">
							<a class="carousel-item" href="">
								<div class="logo">
									<img src="{{ asset('/vendor/' . $group_name . '/' . $skin . '/images/ub.png?t=' . time()) }}" alt="">
								</div>
								<h3 class="name">ỦY BAN ATGTQG</h3>
							</a>
							<a class="carousel-item" href="">
								<div class="logo">
									<img src="{{ asset('/vendor/' . $group_name . '/' . $skin . '/images/bgd.png?t=' . time()) }}" alt="">
								</div>
								<h3 class="name">BỘ GIÁO DỤC VÀ ĐÀO TẠO</h3>
							</a>
							<a class="carousel-item" href="">
								<div class="logo">
									<img src="{{ asset('/vendor/' . $group_name . '/' . $skin . '/images/duongbo.png?t=' . time()) }}" alt="">
								</div>
								<h3 class="name">TỔNG CỤC ĐBVN</h3>
							</a>
							<a class="carousel-item" href="">
								<div class="logo">
									<img src="{{ asset('/vendor/' . $group_name . '/' . $skin . '/images/giaothong.png?t=' . time()) }}" alt="">
								</div>
								<h3 class="name">CỤC CẢNH SÁT GIAO THÔNG</h3>
							</a>
							<a class="carousel-item" href="">
								<div class="logo">
									<img src="{{ asset('/vendor/' . $group_name . '/' . $skin . '/images/egroup.png?t=' . time()) }}" alt="">
								</div>
								<h3 class="name">TẬP ĐOÀN GIÁO DỤC EGROUP</h3>
							</a>
						</div>
					</div>
				</section>
				<!-- logo list end -->
			</div>