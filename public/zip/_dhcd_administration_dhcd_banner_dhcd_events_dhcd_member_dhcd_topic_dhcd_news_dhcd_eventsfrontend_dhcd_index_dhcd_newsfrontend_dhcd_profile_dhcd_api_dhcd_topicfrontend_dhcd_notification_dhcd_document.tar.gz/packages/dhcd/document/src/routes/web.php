<?php
$adminPrefix = config('site.admin_prefix');
Route::group(array('prefix' => $adminPrefix), function() {
    Route::group(['middleware' => ['adtech.auth', 'adtech.acl']], function () {

        Route::group(['prefix' => 'dhcd/document/cate'], function () {
            Route::get('manage', 'DocumentCateController@manage')
                ->where('as', 'Quản lý danh mục tài liệu')
                ->name('dhcd.document.cate.manage');
            Route::get('add', 'DocumentCateController@add')->name('dhcd.document.cate.add');
            Route::post('create', 'DocumentCateController@create')->name('dhcd.document.cate.create');
            Route::get('data', 'DocumentCateController@data')->name('dhcd.document.cate.data');
            Route::get('edit', 'DocumentCateController@edit')->name('dhcd.document.cate.edit');
            Route::post('update}', 'DocumentCateController@update')->name('dhcd.document.cate.update');
            Route::get('delete', 'DocumentCateController@delete')->name('dhcd.document.cate.delete');
        });
        
         Route::group(['prefix' => 'dhcd/document/type'], function () {
            Route::get('manage', 'DocumentTypeController@manage')
                ->where('as', 'Quản lý loại tài liệu')
                ->name('dhcd.document.type.manage');
            Route::get('add', 'DocumentTypeController@add')->name('dhcd.document.type.add');
            Route::post('create', 'DocumentTypeController@create')->name('dhcd.document.type.create');
            Route::get('data', 'DocumentTypeController@data')->name('dhcd.document.type.data');
            Route::get('edit', 'DocumentTypeController@edit')->name('dhcd.document.type.edit');
            Route::post('update}', 'DocumentTypeController@update')->name('dhcd.document.type.update');
            Route::get('delete', 'DocumentTypeController@delete')->name('dhcd.document.type.delete');
        });
        
        Route::group(['prefix' => 'dhcd/document/doc'], function () {
            Route::get('manage', 'DocumentController@manage')
                ->where('as', 'Quản lý tài liệu')
                ->name('dhcd.document.doc.manage');
            Route::get('add', 'DocumentController@add')->name('dhcd.document.doc.add');
            Route::post('create', 'DocumentController@create')->name('dhcd.document.doc.create');
            Route::get('data', 'DocumentController@data')->name('dhcd.document.doc.data');
            Route::get('edit', 'DocumentController@edit')->name('dhcd.document.doc.edit');
            Route::post('update}', 'DocumentController@update')->name('dhcd.document.doc.update');
            Route::get('delete', 'DocumentController@delete')->name('dhcd.document.doc.delete');
        });
        
    });
});