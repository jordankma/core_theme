<?php

namespace Test1\Test1\App\Repositories;

use Adtech\Application\Cms\Repositories\Eloquent\Repository;

/**
 * Class DemoRepository
 * @package Test1\Test1\Repositories
 */
class DemoRepository extends Repository
{

    /**
     * @return string
     */
    public function model()
    {
        return 'Test1\Test1\App\Models\Demo';
    }

    public function deleteID($id) {
        return $this->model->where('demo_id', '=', $id)->update(['visible' => 0]);
    }
}
