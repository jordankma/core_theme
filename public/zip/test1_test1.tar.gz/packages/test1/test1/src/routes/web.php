<?php
$adminPrefix = config('site.admin_prefix');
Route::group(array('prefix' => $adminPrefix), function() {
    Route::group(['middleware' => ['adtech.auth', 'adtech.acl']], function () {

        Route::get('test1/test1/demo/log', 'DemoController@log')->name('test1.test1.demo.log');
        Route::get('test1/test1/demo/data', 'DemoController@data')->name('test1.test1.demo.data');
        Route::get('test1/test1/demo/manage', 'DemoController@manage')->name('test1.test1.demo.manage');
        Route::get('test1/test1/demo/create', 'DemoController@create')->name('test1.test1.demo.create');
        Route::post('test1/test1/demo/add', 'DemoController@add')->name('test1.test1.demo.add');
        Route::get('test1/test1/demo/show', 'DemoController@show')->name('test1.test1.demo.show');
        Route::put('test1/test1/demo/update', 'DemoController@update')->name('test1.test1.demo.update');
        Route::get('test1/test1/demo/delete', 'DemoController@delete')->name('test1.test1.demo.delete');
        Route::get('test1/test1/demo/confirm-delete', 'DemoController@getModalDelete')->name('test1.test1.demo.confirm-delete');
    });
});