<?php

namespace Dhcd\Document\App\Repositories;

use Adtech\Application\Cms\Repositories\Eloquent\Repository;
use Illuminate\Support\Facades\DB;
use Dhcd\Document\App\Models\DocumentType;
use Cache;
/**
 * Class DemoRepository
 * @package Dhcd\Document\Repositories
 */
class DocumentTypeRepository extends Repository
{

    /**
     * @return string
     */
    public function model()
    {
        return 'Dhcd\Document\App\Models\DocumentType';
    }

    public function findAll() {

        $result = $this->model::query();
        return $result;
    }
    
    public static function getTypes(){
        
        if(Cache::has('list_type')){            
            $types = Cache::get('list_type');            
            return $types;            
        } else {
            $types = DocumentType::get()->toArray();
            $data = [];
            if($types){
                Cache::forever('list_type',$types);
                $data = $types;                
            }
            return $data;
        }        
    }
}
