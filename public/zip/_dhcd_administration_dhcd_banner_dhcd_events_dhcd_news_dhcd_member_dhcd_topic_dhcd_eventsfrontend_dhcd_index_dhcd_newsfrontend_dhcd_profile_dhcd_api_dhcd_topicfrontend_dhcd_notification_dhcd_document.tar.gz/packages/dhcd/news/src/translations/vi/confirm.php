<?php

return [
    "cancel" => "Hủy",
    "confirm" => "Chấp nhận",
    "news" => [
    	"delete"=>[
        	"title" => "Xóa tin tức",
        	"body" => "Bạn có chắc muốn xóa tin này?"
    	]
    ],
    "news_tag" => [
        "delete"=>[
            "title" => "Xóa tag",
            "body" => "Bạn có chắc muốn xóa tag này?"
        ]
    ],
    "news_cat" => [
        "delete"=>[
            "title" => "Delete category",
            "body" => "Bạn có chắc muốn xóa category này?"
        ]
    ],
];
