<?php

return [
    "cancel" => "Cancel",
    "confirm" => "Confirm",
    "contact" => [
    	"delete"=>[
        	"title" => "Xóa liên hệ ",
        	"body" => "Bạn có chắc muốn xóa liên hệ này"
    	]
    ],
];
