<p>Dear <strong>{{ $toName }}</strong>,</p>
The password for your Admicro Account (<i>{{ $email }}</i>) has been successfully reset.
<p>If you didn’t make this change or if you believe an unauthorized person has accessed your account, go to admicro.vn
    to reset your password immediately. Then sign into your Admicro account page at {{ $loginLink }} to review and
    update your security settings.</p>
<p></p>
<p></p>
<p>If you need additional help, contact Admicro Support.</p>
<p></p>
<p></p>
<p>Admicro Support</p>