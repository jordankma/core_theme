<ul id="menu" class="page-sidebar-menu">
    @include('includes.frontend.menu')
</ul>
